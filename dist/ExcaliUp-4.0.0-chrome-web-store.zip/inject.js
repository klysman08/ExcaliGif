// Excali Up injected script
// Runs in the main context of the page to access React Fiber internals and the Canvas imageCache

(function() {
  console.log("[Excali Up] Inject script loaded.");

  const Core = window.ExcaliupCore;
  if (!Core) {
    console.error('[Excali Up] Runtime core is unavailable.');
    return;
  }

  let currentApp = null;
  const activeGifs = new Map(); // fileId -> GifPlayer instance
  const activeAnimatedSvgs = new Map(); // fileId -> AnimatedSvgPlayer instance
  const pendingAnimatedSvgImports = [];
  const currentSettings = { ...Core.DEFAULT_SETTINGS };

  // Iconify sidebar state
  let sidebarElement = null;
  let sidebarButton = null;
  let isDraggingIcon = false;
  let draggingIconData = null;
  let iconCollections = null;
  let visibleIcons = [];
  let activePrefix = '';
  let activeCategory = '';
  let activeTag = '';
  let iconView = 'browse';
  let searchQuery = '';
  let currentPage = 1;
  const pageSize = 96;
  const svgCache = new Map();
  let iconSearchTimer = null;
  let iconRequestId = 0;
  let iconCollectionsPromise = null;
  let iconFetchController = null;
  const favoriteIcons = new Set();

  try {
    const savedFavorites = JSON.parse(localStorage.getItem('excaliup_icon_favorites') || '[]');
    if (Array.isArray(savedFavorites)) {
      for (const iconName of savedFavorites) {
        if (typeof iconName === 'string' && /^[a-z0-9]+(?:-[a-z0-9]+)*:[a-z0-9]+(?:-[a-z0-9]+)*$/.test(iconName)) {
          favoriteIcons.add(iconName);
        }
      }
    }
  } catch (error) {
    console.error('[Excali Up] Error loading favorite icons:', error);
  }

  function saveFavoriteIcons() {
    try {
      localStorage.setItem('excaliup_icon_favorites', JSON.stringify([...favoriteIcons]));
    } catch (error) {
      console.error('[Excali Up] Error saving favorite icons:', error);
    }
  }

  let overlayAnimationFrameId = null;
  let svgOverlayTimer = null;
  let gifSchedulerTimer = null;
  let flowOffset = 0;
  let lastFlowDrawAt = 0;
  const flowFrameBudget = new Core.AdaptiveFrameBudget();
  const geometryCache = new Map();

  // Per-element animation assignments: elementId -> animation configuration
  const animatedElements = new Map();
  let toolbarElement = null;
  let lastSelectedId = null;
  let toolbarRenderSignature = '';
  let animatedElementsRevision = 0;
  let saveAnimatedElementsTimer = null;
  let animationMetadataTimer = null;
  const pendingAnimationMetadata = new Map();
  const pendingAnimationMetadataRemovals = new Set();
  const ANIMATION_METADATA_KEY = 'excaliupAnimation';
  const OLD_ANIMATION_METADATA_KEY = 'excaligifAnimation';

  // Load animated elements from localStorage
  try {
    let saved = localStorage.getItem('excaliup_animated_elements');
    if (!saved) {
      saved = localStorage.getItem('excaligif_animated_elements');
    }
    if (saved) {
      const parsed = JSON.parse(saved);
      for (const [id, config] of Object.entries(parsed)) {
        animatedElements.set(id, Core.normalizeElementConfig(config));
      }
      animatedElementsRevision++;
    }
  } catch (e) {
    console.error("[Excali Up] Error loading animated elements:", e);
  }

  function saveAnimatedElements(immediate = false) {
    const write = () => {
      saveAnimatedElementsTimer = null;
      try {
        const obj = {};
        for (const [id, config] of animatedElements.entries()) {
          obj[id] = config;
        }
        localStorage.setItem('excaliup_animated_elements', JSON.stringify(obj));
      } catch (error) {
        console.error('[Excali Up] Error saving animated elements:', error);
      }
    };

    if (saveAnimatedElementsTimer) clearTimeout(saveAnimatedElementsTimer);
    if (immediate) {
      write();
    } else {
      saveAnimatedElementsTimer = setTimeout(write, 150);
    }
  }

  function animationConfigsEqual(first, second) {
    if (!first || !second) return false;
    const firstConfig = Core.normalizeElementConfig(first);
    const secondConfig = Core.normalizeElementConfig(second);
    return Object.keys(DEFAULT_ELEMENT_CONFIG).every((key) => firstConfig[key] === secondConfig[key]);
  }

  function getElementAnimationMetadata(element) {
    const metadata = element && element.customData && element.customData[ANIMATION_METADATA_KEY];
    return metadata && typeof metadata === 'object'
      ? Core.normalizeElementConfig(metadata)
      : null;
  }

  function flushAnimationMetadata() {
    if (animationMetadataTimer) {
      clearTimeout(animationMetadataTimer);
      animationMetadataTimer = null;
    }
    if (
      !currentApp ||
      !currentApp.api ||
      (pendingAnimationMetadata.size === 0 && pendingAnimationMetadataRemovals.size === 0)
    ) {
      return;
    }

    const now = Date.now();
    let changed = false;
    const elements = currentApp.api.getSceneElements();
    const nextElements = elements.map((element) => {
      if (pendingAnimationMetadata.has(element.id)) {
        const config = Core.normalizeElementConfig(pendingAnimationMetadata.get(element.id));
        if (animationConfigsEqual(getElementAnimationMetadata(element), config)) return element;

        changed = true;
        return {
          ...element,
          customData: {
            ...(element.customData || {}),
            [ANIMATION_METADATA_KEY]: config
          },
          version: (element.version || 0) + 1,
          versionNonce: Math.floor(Math.random() * 0x7fffffff),
          updated: now
        };
      }

      if (pendingAnimationMetadataRemovals.has(element.id) && getElementAnimationMetadata(element)) {
        const customData = { ...(element.customData || {}) };
        delete customData[ANIMATION_METADATA_KEY];
        changed = true;
        return {
          ...element,
          customData: Object.keys(customData).length > 0 ? customData : undefined,
          version: (element.version || 0) + 1,
          versionNonce: Math.floor(Math.random() * 0x7fffffff),
          updated: now
        };
      }

      return element;
    });

    pendingAnimationMetadata.clear();
    pendingAnimationMetadataRemovals.clear();
    if (changed) currentApp.api.updateScene({ elements: nextElements });
  }

  function queueAnimationMetadata(configById, removedIds = [], immediate = false) {
    for (const [elementId, config] of configById.entries()) {
      pendingAnimationMetadataRemovals.delete(elementId);
      pendingAnimationMetadata.set(elementId, Core.normalizeElementConfig(config));
    }
    for (const elementId of removedIds) {
      pendingAnimationMetadata.delete(elementId);
      pendingAnimationMetadataRemovals.add(elementId);
    }

    if (animationMetadataTimer) clearTimeout(animationMetadataTimer);
    if (immediate) {
      flushAnimationMetadata();
    } else {
      animationMetadataTimer = setTimeout(flushAnimationMetadata, 150);
    }
  }

  function syncAnimatedElementsFromScene(elements) {
    const metadataToMigrate = new Map();
    let changed = false;

    for (const element of elements) {
      if (!isAnimatableElement(element)) continue;
      const metadata = getElementAnimationMetadata(element);
      const storedConfig = animatedElements.get(element.id);

      if (metadata) {
        if (!storedConfig || !animationConfigsEqual(storedConfig, metadata)) {
          animatedElements.set(element.id, metadata);
          changed = true;
        }
      } else if (storedConfig) {
        metadataToMigrate.set(element.id, storedConfig);
      }
    }

    if (metadataToMigrate.size > 0) queueAnimationMetadata(metadataToMigrate, [], true);
    if (changed) {
      animatedElementsRevision++;
      toolbarRenderSignature = '';
      saveAnimatedElements(false);
    }
    return changed;
  }

  // Load settings from localStorage if available
  try {
    let saved = localStorage.getItem('excaliup_settings');
    if (!saved) {
      saved = localStorage.getItem('excaligif_settings');
    }
    if (saved) {
      const parsed = JSON.parse(saved);
      Object.assign(currentSettings, Core.normalizeSettings(parsed, currentSettings));
    }
  } catch (e) {
    console.error("[Excali Up] Error loading saved settings:", e);
  }


  class GifPlayer {
    constructor(fileId, cacheEntry, app) {
      this.fileId = fileId;
      this.cacheEntry = cacheEntry;
      this.app = app;
      this.originalImage = cacheEntry.image;
      this.width = 0;
      this.height = 0;
      this.frames = [];
      this.currentFrameIdx = 0;
      this.activeCanvas = null;
      this.activeCtx = null;
      this.isLoaded = false;
      this.isDestroyed = false;
      this.isPlaying = false;
      this.nextFrameAt = Infinity;
      this.decodeGeneration = 0;
      this.abortController = null;
      this.loadPromise = this.init();
    }

    async init() {
      const src = this.originalImage.src;
      const generation = ++this.decodeGeneration;
      if (this.abortController) this.abortController.abort();
      this.abortController = null;

      // Skip empty, invalid, or standard transparent 1x1 GIF placeholder sources
      if (!src || src.startsWith('data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7')) {
        this.lastSrc = src;
        console.log("[Excali Up] Skipping empty/placeholder image source for fileId:", this.fileId);
        return;
      }

      const abortController = new AbortController();
      this.abortController = abortController;
      this.lastSrc = src;

      try {
        console.log("[Excali Up] Fetching GIF data for fileId:", this.fileId, "src:", src.substring(0, 100));
        const response = await fetch(src, { signal: abortController.signal });
        if (!response.ok && !src.startsWith('data:') && !src.startsWith('blob:')) {
          throw new Error(`GIF request failed with status ${response.status}`);
        }
        const arrayBuffer = await response.arrayBuffer();
        if (this.isDestroyed || generation !== this.decodeGeneration) return;
        const bytes = new Uint8Array(arrayBuffer);

        // window.GifReader is loaded by omggif.js in the page scope
        if (typeof window.GifReader === 'undefined' && typeof GifReader === 'undefined') {
          throw new Error("GifReader is not defined in the scope.");
        }
        const ReaderClass = typeof window.GifReader !== 'undefined' ? window.GifReader : GifReader;
        const reader = new ReaderClass(bytes);
        const width = reader.width;
        const height = reader.height;
        const numFrames = reader.numFrames();
        console.log(`[Excali Up] Decoding GIF: ${width}x${height}, ${numFrames} frames`);
        if (numFrames <= 0) return;

        const decodedFrames = [];
        const accumBuffer = new Uint8ClampedArray(width * height * 4);
        let backupBuffer = null;

        for (let i = 0; i < numFrames; i++) {
          if (this.isDestroyed || generation !== this.decodeGeneration) {
            this.releaseFrames(decodedFrames);
            return;
          }

          const info = reader.frameInfo(i);

          // 1. Handle disposal of previous frame
          if (i > 0) {
            const prevInfo = reader.frameInfo(i - 1);
            if (prevInfo.disposal === 2) {
              // Restore to background (clear the subrect to transparent)
              for (let y = prevInfo.y; y < prevInfo.y + prevInfo.height; y++) {
                for (let x = prevInfo.x; x < prevInfo.x + prevInfo.width; x++) {
                  const idx = (y * width + x) * 4;
                  accumBuffer[idx] = 0;
                  accumBuffer[idx + 1] = 0;
                  accumBuffer[idx + 2] = 0;
                  accumBuffer[idx + 3] = 0;
                }
              }
            } else if (prevInfo.disposal === 3 && backupBuffer) {
              // Restore to state before previous frame
              accumBuffer.set(backupBuffer);
            }
          }
          
          // 2. Backup buffer before drawing current frame if its disposal is 3
          if (info.disposal === 3) {
            if (!backupBuffer) {
              backupBuffer = new Uint8ClampedArray(width * height * 4);
            }
            backupBuffer.set(accumBuffer);
          }

          // 3. Decode frame pixels directly into the accumulated buffer
          reader.decodeAndBlitFrameRGBA(i, accumBuffer);

          // 4. Draw accumBuffer onto a frame canvas
          const frameCanvas = document.createElement('canvas');
          frameCanvas.width = width;
          frameCanvas.height = height;
          const frameCtx = frameCanvas.getContext('2d');
          const imgData = frameCtx.createImageData(width, height);
          imgData.data.set(accumBuffer);
          frameCtx.putImageData(imgData, 0, 0);

          // Delay is in hundredths of a second (10ms)
          const baseDelay = info.delay * 10 || 100; // default to 100ms

          decodedFrames.push({
            image: frameCanvas,
            delay: baseDelay
          });
        }

        if (this.isDestroyed || generation !== this.decodeGeneration) {
          this.releaseFrames(decodedFrames);
          return;
        }

        this.releaseFrames();
        this.frames = decodedFrames;
        this.width = width;
        this.height = height;
        this.currentFrameIdx = 0;

        // Setup active canvas that Excalidraw draws
        const activeCanvas = document.createElement('canvas');
        activeCanvas.width = width;
        activeCanvas.height = height;

        // Mock standard HTMLImageElement properties
        Object.defineProperties(activeCanvas, {
          tagName: { value: 'IMG' },
          complete: { value: true },
          naturalWidth: { value: width },
          naturalHeight: { value: height }
        });

        if (this.activeCanvas) {
          this.activeCanvas.width = 0;
          this.activeCanvas.height = 0;
        }
        this.activeCanvas = activeCanvas;
        this.activeCtx = activeCanvas.getContext('2d');
        this.isLoaded = true;

        if (currentSettings.gifsEnabled) {
          this.start();
        }
      } catch (e) {
        if (e.name !== 'AbortError') {
          console.error("[Excali Up] Error initializing player for fileId " + this.fileId, e);
        }
      } finally {
        if (this.abortController === abortController) this.abortController = null;
      }
    }

    releaseFrames(frames = this.frames) {
      for (const frame of frames) {
        if (frame.image && typeof frame.image.close === 'function') {
          frame.image.close();
        } else if (frame.image) {
          frame.image.width = 0;
          frame.image.height = 0;
        }
      }
      if (frames === this.frames) this.frames = [];
    }

    start() {
      if (this.isDestroyed || !this.isLoaded) return;

      // Swap out the image in Excalidraw cache
      this.cacheEntry.image = this.activeCanvas;
      this.isPlaying = true;
      this.nextFrameAt = performance.now();
      scheduleGifTick();
    }

    renderDue(now, tolerance = 4) {
      if (
        this.isDestroyed ||
        !this.isLoaded ||
        !this.isPlaying ||
        !currentSettings.gifsEnabled ||
        this.nextFrameAt - now > tolerance
      ) {
        return false;
      }

      const frame = this.frames[this.currentFrameIdx];
      if (!frame) return false;
      this.activeCtx.clearRect(0, 0, this.width, this.height);
      this.activeCtx.drawImage(frame.image, 0, 0);

      this.currentFrameIdx = (this.currentFrameIdx + 1) % this.frames.length;
      const speedMultiplier = currentSettings.gifSpeed || 1;
      this.nextFrameAt = now + Math.max(10, Math.round(frame.delay / speedMultiplier));
      return true;
    }

    stop() {
      this.isPlaying = false;
      this.nextFrameAt = Infinity;
      // Restore original static image
      if (this.cacheEntry) this.cacheEntry.image = this.originalImage;
      scheduleGifTick();
    }

    destroy() {
      this.stop();
      this.isDestroyed = true;
      this.decodeGeneration++;
      if (this.abortController) this.abortController.abort();
      this.abortController = null;
      this.releaseFrames();
      if (this.activeCanvas) {
        this.activeCanvas.width = 0;
        this.activeCanvas.height = 0;
      }
      this.activeCanvas = null;
      this.activeCtx = null;
      this.isLoaded = false;
    }
  }

  function queueAnimatedSvgImport(markup) {
    if (!Core.isAnimatedSvgMarkup(markup)) return false;
    const now = Date.now();
    while (pendingAnimatedSvgImports.length && pendingAnimatedSvgImports[0].expiresAt <= now) {
      pendingAnimatedSvgImports.shift();
    }
    pendingAnimatedSvgImports.push({ markup, expiresAt: now + 10000 });
    return true;
  }

  function takePendingAnimatedSvgImport() {
    const now = Date.now();
    while (pendingAnimatedSvgImports.length && pendingAnimatedSvgImports[0].expiresAt <= now) {
      pendingAnimatedSvgImports.shift();
    }
    const pending = pendingAnimatedSvgImports.shift();
    return pending ? pending.markup : null;
  }

  function sanitizeAnimatedSvgMarkup(markup) {
    const documentNode = new DOMParser().parseFromString(markup, 'image/svg+xml');
    if (documentNode.querySelector('parsererror') || documentNode.documentElement.localName !== 'svg') {
      throw new Error('Invalid animated SVG');
    }

    for (const node of documentNode.querySelectorAll('script, foreignObject, iframe, object, embed')) {
      node.remove();
    }
    for (const node of documentNode.querySelectorAll('*')) {
      for (const attribute of [...node.attributes]) {
        const name = attribute.name.toLowerCase();
        const value = attribute.value.trim();
        if (name.startsWith('on')) {
          node.removeAttribute(attribute.name);
        } else if ((name === 'href' || name === 'xlink:href') && value && !value.startsWith('#')) {
          node.removeAttribute(attribute.name);
        }
      }
    }

    const svg = documentNode.documentElement;
    for (const animation of svg.querySelectorAll('animate, animateTransform, animateMotion')) {
      animation.setAttribute('repeatCount', 'indefinite');
    }
    const loopStyle = documentNode.createElementNS('http://www.w3.org/2000/svg', 'style');
    loopStyle.textContent = '* { animation-iteration-count: infinite !important; }';
    svg.appendChild(loopStyle);
    svg.setAttribute('width', '100%');
    svg.setAttribute('height', '100%');
    svg.setAttribute('preserveAspectRatio', svg.getAttribute('preserveAspectRatio') || 'xMidYMid meet');
    svg.style.display = 'block';
    return svg.outerHTML;
  }

  function ensureAnimatedSvgOverlay() {
    const interactiveCanvas = document.querySelector('.excalidraw__canvas.interactive');
    if (!interactiveCanvas || !interactiveCanvas.parentNode) return null;

    let overlay = document.getElementById('ExcaliGifSvgOverlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'ExcaliGifSvgOverlay';
      overlay.style.position = 'absolute';
      overlay.style.top = '0';
      overlay.style.left = '0';
      overlay.style.overflow = 'hidden';
      overlay.style.pointerEvents = 'none';
      overlay.style.zIndex = '2';
      interactiveCanvas.parentNode.insertBefore(overlay, interactiveCanvas.nextSibling);
      if (window.getComputedStyle(interactiveCanvas.parentNode).position === 'static') {
        interactiveCanvas.parentNode.style.position = 'relative';
      }
    }

    const width = interactiveCanvas.clientWidth;
    const height = interactiveCanvas.clientHeight;
    overlay.style.width = `${width}px`;
    overlay.style.height = `${height}px`;
    return overlay;
  }

  function removeAnimatedSvgOverlayIfEmpty() {
    const overlay = document.getElementById('ExcaliGifSvgOverlay');
    if (overlay && !overlay.childElementCount) overlay.remove();
  }

  function stopAnimatedSvgOverlayLoop() {
    if (svgOverlayTimer) {
      clearTimeout(svgOverlayTimer);
      svgOverlayTimer = null;
    }
  }

  function updateAnimatedSvgOverlay() {
    svgOverlayTimer = null;
    if (document.hidden || !currentSettings.animatedSvgsEnabled || !currentApp || !activeAnimatedSvgs.size) return;

    const overlay = ensureAnimatedSvgOverlay();
    if (!overlay) return;
    const elements = currentApp.api.getSceneElements();
    const imagesByFileId = new Map();
    for (const element of elements) {
      if (element.type === 'image' && !element.isDeleted && element.fileId) {
        if (!imagesByFileId.has(element.fileId)) imagesByFileId.set(element.fileId, []);
        imagesByFileId.get(element.fileId).push(element);
      }
    }

    const zoom = currentApp.state.zoom ? currentApp.state.zoom.value : 1;
    const scrollX = currentApp.state.scrollX || 0;
    const scrollY = currentApp.state.scrollY || 0;
    for (const player of activeAnimatedSvgs.values()) {
      const playerElements = player.isPlaying ? imagesByFileId.get(player.fileId) || [] : [];
      player.syncOverlayElements(playerElements);
      for (const element of playerElements) {
        const overlayElement = player.overlayElements.get(element.id);
        if (!overlayElement) continue;
        const scaleX = Array.isArray(element.scale) ? element.scale[0] : 1;
        const scaleY = Array.isArray(element.scale) ? element.scale[1] : 1;
        const left = (element.x + scrollX) * zoom;
        const top = (element.y + scrollY) * zoom;
        const width = Math.abs(element.width * zoom);
        const height = Math.abs(element.height * zoom);
        const angle = element.angle || 0;
        const opacity = element.opacity == null ? 1 : element.opacity / 100;
        const signature = [left, top, width, height, angle, scaleX, scaleY, opacity]
          .map(value => Math.round(value * 1000) / 1000)
          .join(':');

        if (signature !== player.lastTransforms.get(element.id)) {
          player.lastTransforms.set(element.id, signature);
          const style = overlayElement.style;
          style.left = `${left}px`;
          style.top = `${top}px`;
          style.width = `${width}px`;
          style.height = `${height}px`;
          style.opacity = String(opacity);
          style.transform = `rotate(${angle}rad) scale(${scaleX}, ${scaleY})`;
        }
        overlayElement.style.display = 'block';
      }
    }

    // The SVG timeline is browser-native; this timer only tracks Excalidraw transforms.
    svgOverlayTimer = setTimeout(updateAnimatedSvgOverlay, 33);
  }

  function scheduleAnimatedSvgOverlay() {
    if (!svgOverlayTimer && !document.hidden && currentSettings.animatedSvgsEnabled && currentApp) {
      svgOverlayTimer = setTimeout(updateAnimatedSvgOverlay, 0);
    }
  }

  class AnimatedSvgPlayer {
    constructor(fileId, cacheEntry, sourceMarkup = null) {
      this.fileId = fileId;
      this.cacheEntry = cacheEntry;
      this.originalImage = cacheEntry.image;
      this.sourceMarkup = sourceMarkup;
      this.safeMarkup = '';
      this.transparentCanvas = null;
      this.overlayElements = new Map();
      this.svgElements = new Map();
      this.lastTransforms = new Map();
      this.lastSrc = '';
      this.isLoaded = false;
      this.isPlaying = false;
      this.isDestroyed = false;
      this.decodeGeneration = 0;
      this.abortController = null;
      this.loadPromise = this.init();
    }

    async init() {
      const src = this.cacheEntry && this.cacheEntry.image && this.cacheEntry.image.src;
      const generation = ++this.decodeGeneration;
      if (this.abortController) this.abortController.abort();
      this.abortController = null;
      this.lastSrc = src || '';
      this.isLoaded = false;

      if (!src && !this.sourceMarkup) return;
      // Let the image-cache hook register this player before any scene refresh can run.
      await Promise.resolve();
      if (this.isDestroyed || generation !== this.decodeGeneration) return;

      const abortController = new AbortController();
      this.abortController = abortController;
      try {
        let markup = this.sourceMarkup;
        if (!markup) {
          const response = await fetch(src, { signal: abortController.signal });
          if (!response.ok && !src.startsWith('data:') && !src.startsWith('blob:')) {
            throw new Error(`SVG request failed with status ${response.status}`);
          }
          markup = await response.text();
        }
        if (this.isDestroyed || generation !== this.decodeGeneration) return;

        if (!Core.isAnimatedSvgMarkup(markup)) {
          if (activeAnimatedSvgs.get(this.fileId) === this) activeAnimatedSvgs.delete(this.fileId);
          return;
        }

        const intrinsicSize = Core.getSvgIntrinsicSize(markup, 96);
        const safeMarkup = sanitizeAnimatedSvgMarkup(markup);
        if (this.isDestroyed || generation !== this.decodeGeneration) return;

        const width = intrinsicSize.width;
        const height = intrinsicSize.height;
        const transparentCanvas = document.createElement('canvas');
        transparentCanvas.width = width;
        transparentCanvas.height = height;
        Object.defineProperties(transparentCanvas, {
          tagName: { value: 'IMG' },
          complete: { value: true },
          naturalWidth: { value: width },
          naturalHeight: { value: height }
        });

        this.safeMarkup = safeMarkup;
        this.transparentCanvas = transparentCanvas;
        this.isLoaded = true;
        if (currentSettings.animatedSvgsEnabled) this.start();
      } catch (error) {
        if (error.name !== 'AbortError') {
          console.error(`[Excali Up] Animated SVG detection failed for ${this.fileId}:`, error);
        }
      } finally {
        if (this.abortController === abortController) this.abortController = null;
      }
    }

    updateCacheEntry(cacheEntry) {
      const incomingImage = cacheEntry && cacheEntry.image;
      this.cacheEntry = cacheEntry;
      if (this.isLoaded && this.transparentCanvas && this.isPlaying) {
        cacheEntry.image = this.transparentCanvas;
        return;
      }
      if (incomingImage) this.originalImage = incomingImage;
      const src = incomingImage && incomingImage.src;
      if (src && src !== this.lastSrc && !this.sourceMarkup) this.loadPromise = this.init();
    }

    syncOverlayElements(elements) {
      const activeElementIds = new Set(elements.map(element => element.id));
      for (const [elementId, overlayElement] of this.overlayElements.entries()) {
        if (!activeElementIds.has(elementId)) {
          overlayElement.remove();
          this.overlayElements.delete(elementId);
          this.svgElements.delete(elementId);
          this.lastTransforms.delete(elementId);
        }
      }

      const overlay = ensureAnimatedSvgOverlay();
      if (!overlay) return;
      for (const element of elements) {
        if (this.overlayElements.has(element.id)) continue;
        const overlayElement = document.createElement('div');
        overlayElement.dataset.fileId = this.fileId;
        overlayElement.dataset.elementId = element.id;
        overlayElement.style.position = 'absolute';
        overlayElement.style.transformOrigin = 'center center';
        overlayElement.style.pointerEvents = 'none';
        overlayElement.style.display = 'none';
        const shadowRoot = overlayElement.attachShadow({ mode: 'closed' });
        shadowRoot.innerHTML = this.safeMarkup;
        overlay.appendChild(overlayElement);
        this.overlayElements.set(element.id, overlayElement);
        this.svgElements.set(element.id, shadowRoot.querySelector('svg'));
      }
    }

    start() {
      if (this.isDestroyed || !this.isLoaded) return;
      if (this.cacheEntry && this.transparentCanvas) this.cacheEntry.image = this.transparentCanvas;
      this.isPlaying = true;
      for (const svgElement of this.svgElements.values()) {
        if (svgElement && typeof svgElement.unpauseAnimations === 'function') svgElement.unpauseAnimations();
      }
      refreshGifElements(new Set([this.fileId]));
      scheduleAnimatedSvgOverlay();
    }

    stop() {
      this.isPlaying = false;
      if (this.cacheEntry && this.originalImage) this.cacheEntry.image = this.originalImage;
      for (const overlayElement of this.overlayElements.values()) overlayElement.style.display = 'none';
      for (const svgElement of this.svgElements.values()) {
        if (svgElement && typeof svgElement.pauseAnimations === 'function') svgElement.pauseAnimations();
      }
      if (!this.isDestroyed) refreshGifElements(new Set([this.fileId]));
    }

    destroy() {
      this.stop();
      this.isDestroyed = true;
      this.decodeGeneration++;
      if (this.abortController) this.abortController.abort();
      this.abortController = null;
      for (const overlayElement of this.overlayElements.values()) overlayElement.remove();
      if (this.transparentCanvas) {
        this.transparentCanvas.width = 0;
        this.transparentCanvas.height = 0;
      }
      this.overlayElements.clear();
      this.svgElements.clear();
      this.lastTransforms.clear();
      this.transparentCanvas = null;
      this.cacheEntry = null;
      this.isLoaded = false;
      removeAnimatedSvgOverlayIfEmpty();
    }
  }

  function stopGifScheduler() {
    if (gifSchedulerTimer) {
      clearTimeout(gifSchedulerTimer);
      gifSchedulerTimer = null;
    }
  }

  function scheduleGifTick() {
    stopGifScheduler();
    if (document.hidden || !currentSettings.gifsEnabled || !currentApp) return;

    let nextFrameAt = Infinity;
    for (const player of activeGifs.values()) {
      if (player.isPlaying && player.isLoaded && !player.isDestroyed) {
        nextFrameAt = Math.min(nextFrameAt, player.nextFrameAt);
      }
    }
    if (!Number.isFinite(nextFrameAt)) return;

    const delay = Math.max(0, nextFrameAt - performance.now());
    gifSchedulerTimer = setTimeout(runGifScheduler, delay);
  }

  function runGifScheduler() {
    gifSchedulerTimer = null;
    if (document.hidden || !currentSettings.gifsEnabled || !currentApp) return;

    const now = performance.now();
    const dueFileIds = new Set();
    for (const [fileId, player] of activeGifs.entries()) {
      if (player.renderDue(now)) dueFileIds.add(fileId);
    }

    refreshGifElements(dueFileIds);

    scheduleGifTick();
  }

  function refreshGifElements(fileIds) {
    if (!currentApp || !currentApp.api) return;
    const elements = currentApp.api.getSceneElements();
    const refresh = Core.buildGifRefreshElements(elements, fileIds);
    if (refresh.changed) currentApp.api.updateScene({ elements: refresh.elements });
  }

  // Traverse DOM up to find Excalidraw class instance
  function findExcalidrawInstance() {
    const canvas = document.querySelector('.excalidraw__canvas.interactive');
    if (!canvas) return null;
    const key = Object.keys(canvas).find(k => k.startsWith('__reactFiber$'));
    if (!key) return null;
    let fiber = canvas[key];
    while (fiber) {
      if (fiber.stateNode && !(fiber.stateNode instanceof HTMLElement) && !(fiber.stateNode instanceof Window)) {
        if (fiber.stateNode.imageCache) {
          return fiber.stateNode;
        }
      }
      fiber = fiber.return;
    }
    return null;
  }

  function hookImageCache(app) {
    if (app.imageCache && !app.imageCache.excaligifHook) {
      const originalSet = app.imageCache.set;

      const wrappedSet = function(fileId, cacheEntry) {
        const res = originalSet.apply(this, arguments);
        if (cacheEntry && cacheEntry.mimeType === 'image/gif') {
          if (!activeGifs.has(fileId)) {
            console.log("[Excali Up] Hooked new GIF fileId:", fileId);
            activeGifs.set(fileId, new GifPlayer(fileId, cacheEntry, app));
          } else {
            const player = activeGifs.get(fileId);
            player.cacheEntry = cacheEntry;
            
            // Check if the image source changed from the placeholder to a real URL
            if (cacheEntry.image && cacheEntry.image.src && cacheEntry.image.src !== player.lastSrc) {
              console.log("[Excali Up] Image source changed for fileId:", fileId, ". Re-initializing...");
              player.originalImage = cacheEntry.image;
              player.loadPromise = player.init();
            }

            if (currentSettings.gifsEnabled && player.activeCanvas) {
              cacheEntry.image = player.activeCanvas;
            }
          }
        } else if (cacheEntry && cacheEntry.mimeType === 'image/svg+xml') {
          if (!activeAnimatedSvgs.has(fileId)) {
            const sourceMarkup = takePendingAnimatedSvgImport();
            activeAnimatedSvgs.set(fileId, new AnimatedSvgPlayer(fileId, cacheEntry, sourceMarkup));
          } else {
            activeAnimatedSvgs.get(fileId).updateCacheEntry(cacheEntry);
          }
        }
        return res;
      };

      app.imageCache.set = wrappedSet;
      app.imageCache.excaligifHook = { originalSet, wrappedSet };

      // Scan existing GIF cache entries
      for (const [fileId, cacheEntry] of app.imageCache.entries()) {
        if (cacheEntry && cacheEntry.mimeType === 'image/gif' && !activeGifs.has(fileId)) {
          console.log("[Excali Up] Hooked existing GIF fileId:", fileId);
          activeGifs.set(fileId, new GifPlayer(fileId, cacheEntry, app));
        } else if (cacheEntry && cacheEntry.mimeType === 'image/svg+xml' && !activeAnimatedSvgs.has(fileId)) {
          activeAnimatedSvgs.set(fileId, new AnimatedSvgPlayer(fileId, cacheEntry));
        }
      }
    }
  }

  function unhookImageCache(app) {
    const hook = app && app.imageCache && app.imageCache.excaligifHook;
    if (!hook) return;
    if (app.imageCache.set === hook.wrappedSet) app.imageCache.set = hook.originalSet;
    delete app.imageCache.excaligifHook;
  }

  function detachCurrentApp() {
    stopGifScheduler();
    stopOverlayLoop();
    stopAnimatedSvgOverlayLoop();
    if (animationMetadataTimer) clearTimeout(animationMetadataTimer);
    animationMetadataTimer = null;
    pendingAnimationMetadata.clear();
    pendingAnimationMetadataRemovals.clear();
    for (const player of activeGifs.values()) player.destroy();
    activeGifs.clear();
    for (const player of activeAnimatedSvgs.values()) player.destroy();
    activeAnimatedSvgs.clear();
    pendingAnimatedSvgImports.length = 0;
    geometryCache.clear();
    unhookImageCache(currentApp);
    removeSidebarElements();
    currentApp = null;
    toolbarRenderSignature = '';
  }

  function attachApp(app) {
    if (app === currentApp) return;
    if (currentApp) detachCurrentApp();

    console.log("[Excali Up] Hooked Excalidraw instance!");
    currentApp = app;
    hookImageCache(app);
    createToolbar();
    createSidebarButtonAndPanel();
    scanAndCleanupMedia();
    updateToolbar(true);
    reconcileRuntime();
  }

  function scanAndCleanupMedia() {
    if (!currentApp) return;
    const elements = currentApp.api ? currentApp.api.getSceneElements() : [];
    const activeFileIds = new Set(elements.filter(e => e.type === 'image').map(e => e.fileId));
    
    for (const [fileId, player] of activeGifs.entries()) {
      const cacheEntry = currentApp.imageCache.get(fileId);
      if (!activeFileIds.has(fileId) || !cacheEntry) {
        console.log("[Excali Up] Cleaning up player for fileId:", fileId);
        player.destroy();
        activeGifs.delete(fileId);
      }
    }
    for (const [fileId, player] of activeAnimatedSvgs.entries()) {
      const cacheEntry = currentApp.imageCache.get(fileId);
      if (!activeFileIds.has(fileId) || !cacheEntry) {
        player.destroy();
        activeAnimatedSvgs.delete(fileId);
      }
    }
    if (!activeAnimatedSvgs.size) stopAnimatedSvgOverlayLoop();
    
    // Avoid erasing persisted assignments while Excalidraw is still hydrating an empty scene.
    if (elements.length === 0) {
      reconcileFlowRuntime();
      return;
    }

    syncAnimatedElementsFromScene(elements);

    // Clean up animated element entries for deleted elements
    const sceneIds = new Set(elements.filter(e => !e.isDeleted).map(e => e.id));
    let cleaned = false;
    for (const elId of animatedElements.keys()) {
      if (!sceneIds.has(elId)) {
        animatedElements.delete(elId);
        geometryCache.delete(elId);
        cleaned = true;
      }
    }
    if (cleaned) {
      animatedElementsRevision++;
      toolbarRenderSignature = '';
      saveAnimatedElements(true);
    }
    reconcileFlowRuntime();
  }

  function checkInstance() {
    const app = findExcalidrawInstance();
    if (app && app !== currentApp) {
      attachApp(app);
    } else if (!app && currentApp) {
      detachCurrentApp();
    }
    scanAndCleanupMedia();
  }

  // Helper functions for path and flow animations
  function isAnimatableElement(element) {
    return !!(
      element &&
      !element.isDeleted &&
      (element.type === 'arrow' || element.type === 'line') &&
      Array.isArray(element.points) &&
      element.points.length >= 2
    );
  }

  function shouldAnimateElement(el) {
    if (!isAnimatableElement(el)) return false;
    // Only animate elements explicitly assigned via the in-canvas toolbar
    return animatedElements.has(el.id);
  }

  const DEFAULT_ELEMENT_CONFIG = Core.DEFAULT_ELEMENT_CONFIG;
  const getPointAtLength = Core.getPointAtLength;

  function getCachedGeometry(element) {
    const cached = geometryCache.get(element.id);
    if (cached && cached.element === element && cached.version === element.version) {
      return cached.geometry;
    }

    const geometry = Core.getPathGeometry(Core.getPathPoints(element));
    geometryCache.set(element.id, {
      element,
      version: element.version,
      geometry
    });
    return geometry;
  }

  function getSceneElementsMap() {
    if (!currentApp) return new Map();
    if (currentApp.scene && typeof currentApp.scene.getNonDeletedElementsMap === 'function') {
      return currentApp.scene.getNonDeletedElementsMap();
    }
    const elements = currentApp.api ? currentApp.api.getSceneElements() : [];
    return new Map(elements.filter((element) => !element.isDeleted).map((element) => [element.id, element]));
  }

  function getElementConfig(elId) {
    return Core.normalizeElementConfig(animatedElements.get(elId), DEFAULT_ELEMENT_CONFIG);
  }

  function getElementOffset(config, globalOffset) {
    return Core.getElementOffset(config, globalOffset);
  }

  function startOverlayLoop() {
    if (
      overlayAnimationFrameId ||
      document.hidden ||
      !currentApp ||
      !currentSettings.flowEnabled ||
      animatedElements.size === 0
    ) {
      return;
    }

    flowFrameBudget.reset(performance.now());
    lastFlowDrawAt = 0;

    function step(timestamp) {
      overlayAnimationFrameId = null;
      if (
        document.hidden ||
        !currentApp ||
        !currentSettings.flowEnabled ||
        animatedElements.size === 0
      ) {
        stopOverlayLoop();
        return;
      }

      const frameDelta = lastFlowDrawAt ? timestamp - lastFlowDrawAt : flowFrameBudget.frameInterval;
      if (!lastFlowDrawAt || frameDelta >= flowFrameBudget.frameInterval - 1) {
        flowOffset += frameDelta / 16.666;
        const drawStartedAt = performance.now();
        drawOverlay(flowOffset);
        flowFrameBudget.record(timestamp, performance.now() - drawStartedAt, frameDelta);
        lastFlowDrawAt = timestamp;
      }

      overlayAnimationFrameId = requestAnimationFrame(step);
    }

    overlayAnimationFrameId = requestAnimationFrame(step);
  }

  function stopOverlayLoop() {
    if (overlayAnimationFrameId) {
      cancelAnimationFrame(overlayAnimationFrameId);
      overlayAnimationFrameId = null;
    }
    // Clear overlay canvas
    const overlayCanvas = document.getElementById('ExcaliGifOverlayCanvas');
    if (overlayCanvas) {
      const ctx = overlayCanvas.getContext('2d');
      ctx.clearRect(0, 0, overlayCanvas.width, overlayCanvas.height);
    }
    lastFlowDrawAt = 0;
  }

  function drawOverlay(offset) {
    const interactiveCanvas = document.querySelector('.excalidraw__canvas.interactive');
    if (!interactiveCanvas || !currentApp || !currentSettings.flowEnabled) {
      const overlayCanvas = document.getElementById('ExcaliGifOverlayCanvas');
      if (overlayCanvas) {
        const ctx = overlayCanvas.getContext('2d');
        ctx.clearRect(0, 0, overlayCanvas.width, overlayCanvas.height);
      }
      return;
    }
    
    let overlayCanvas = document.getElementById('ExcaliGifOverlayCanvas');
    if (!overlayCanvas) {
      overlayCanvas = document.createElement('canvas');
      overlayCanvas.id = 'ExcaliGifOverlayCanvas';
      overlayCanvas.style.position = 'absolute';
      overlayCanvas.style.top = '0';
      overlayCanvas.style.left = '0';
      overlayCanvas.style.pointerEvents = 'none';
      interactiveCanvas.parentNode.insertBefore(overlayCanvas, interactiveCanvas.nextSibling);
      
      if (interactiveCanvas.parentNode && window.getComputedStyle(interactiveCanvas.parentNode).position === 'static') {
        interactiveCanvas.parentNode.style.position = 'relative';
      }
    }

    const width = interactiveCanvas.clientWidth;
    const height = interactiveCanvas.clientHeight;
    const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
    const pixelWidth = Math.round(width * pixelRatio);
    const pixelHeight = Math.round(height * pixelRatio);
    if (overlayCanvas.width !== pixelWidth || overlayCanvas.height !== pixelHeight) {
      overlayCanvas.width = pixelWidth;
      overlayCanvas.height = pixelHeight;
      overlayCanvas.style.width = `${width}px`;
      overlayCanvas.style.height = `${height}px`;
    }

    const ctx = overlayCanvas.getContext('2d');
    ctx.clearRect(0, 0, overlayCanvas.width, overlayCanvas.height);

    ctx.save();
    ctx.scale(pixelRatio, pixelRatio);

    const zoomVal = currentApp.state.zoom ? currentApp.state.zoom.value : 1;
    const scrollXVal = currentApp.state.scrollX || 0;
    const scrollYVal = currentApp.state.scrollY || 0;
    const viewportBounds = Core.getViewportBounds(width, height, zoomVal, scrollXVal, scrollYVal, 40);

    ctx.scale(zoomVal, zoomVal);
    ctx.translate(scrollXVal, scrollYVal);

    const elementsMap = getSceneElementsMap();
    for (const elementId of animatedElements.keys()) {
      const el = elementsMap.get(elementId);
      if (!el || !shouldAnimateElement(el) || (el.type !== 'arrow' && el.type !== 'line')) continue;

      const geometry = getCachedGeometry(el);
      if (geometry.totalLength > 0 && Core.intersectsBounds(geometry.bounds, viewportBounds)) {
        const config = getElementConfig(el.id);
        const elOffset = getElementOffset(config, offset);

        switch (config.style) {
          case 'particles':
            drawParticles(ctx, el, geometry, elOffset, config);
            break;
          case 'dashes':
            drawDashes(ctx, el, geometry, elOffset, config);
            break;
          case 'gradient':
            drawGradientPulse(ctx, el, geometry, elOffset, config);
            break;
          case 'ripple':
            drawRippleWave(ctx, el, geometry, elOffset, config);
            break;
          case 'train':
            drawPacketTrain(ctx, el, geometry, elOffset, config);
            break;
          case 'snake':
            drawSnakeTrail(ctx, el, geometry, elOffset, config);
            break;
          case 'comet':
            drawComet(ctx, el, geometry, elOffset, config);
            break;
          case 'electricity':
            drawElectricity(ctx, el, geometry, elOffset, config);
            break;
          case 'wave':
            drawFlowWave(ctx, el, geometry, elOffset, config);
            break;
          case 'dual':
            drawDualFlow(ctx, el, geometry, elOffset, config);
            break;
          default:
            drawParticles(ctx, el, geometry, elOffset, config);
        }
      }
    }

    ctx.restore();
  }

  function reconcileRuntime() {
    if (currentSettings.gifsEnabled && !document.hidden) {
      for (const player of activeGifs.values()) {
        if (player.isLoaded && !player.isPlaying) player.start();
      }
      scheduleGifTick();
    } else if (!currentSettings.gifsEnabled || document.hidden) {
      for (const player of activeGifs.values()) {
        if (player.isPlaying) player.stop();
      }
      stopGifScheduler();
    }

    if (currentSettings.animatedSvgsEnabled && !document.hidden) {
      for (const player of activeAnimatedSvgs.values()) {
        if (player.isLoaded && !player.isPlaying) player.start();
      }
      scheduleAnimatedSvgOverlay();
    } else {
      for (const player of activeAnimatedSvgs.values()) {
        if (player.isPlaying) player.stop();
      }
      stopAnimatedSvgOverlayLoop();
    }

    reconcileFlowRuntime();
  }

  function hasRenderableAnimatedElements() {
    const elementsMap = getSceneElementsMap();
    for (const elementId of animatedElements.keys()) {
      const element = elementsMap.get(elementId);
      if (element && !element.isDeleted && (element.type === 'arrow' || element.type === 'line')) {
        return true;
      }
    }
    return false;
  }

  function reconcileFlowRuntime() {
    if (
      currentSettings.flowEnabled &&
      !document.hidden &&
      currentApp &&
      hasRenderableAnimatedElements()
    ) {
      startOverlayLoop();
    } else {
      stopOverlayLoop();
    }
  }

  function getGlowBlur(config) {
    const intensity = config.glowIntensity || 'medium';
    switch (intensity) {
      case 'none': return 0;
      case 'subtle': return 3;
      case 'medium': return 6;
      case 'strong': return 14;
      default: return 6;
    }
  }

  function drawParticles(ctx, el, geometry, offset, config) {
    const strokeColor = el.strokeColor || '#1e1e1e';
    const strokeWidth = el.strokeWidth || 2;
    
    ctx.save();
    ctx.fillStyle = strokeColor;
    
    const glowBlur = getGlowBlur(config);
    if (glowBlur > 0) {
      ctx.shadowColor = strokeColor;
      ctx.shadowBlur = glowBlur;
    }
    
    const spacing = config.particleSpacing || 50;
    const sizeFactor = (config.particleSize || 3) / 3;
    const radius = Math.max(1.5, strokeWidth * 0.85 * sizeFactor);
    const totalLength = geometry.totalLength;
    
    let d = ((offset % spacing) + spacing) % spacing;
    while (d < totalLength) {
      const pt = getPointAtLength(geometry, d);
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, radius, 0, Math.PI * 2);
      ctx.fill();
      d += spacing;
    }
    
    ctx.restore();
  }

  function drawDashes(ctx, el, geometry, offset, config) {
    const strokeColor = el.strokeColor || '#1e1e1e';
    const strokeWidth = el.strokeWidth || 2;
    
    ctx.save();
    ctx.strokeStyle = strokeColor;
    const sizeFactor = (config.particleSize || 3) / 3;
    ctx.lineWidth = (strokeWidth + 0.8) * sizeFactor;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    const glowBlur = getGlowBlur(config);
    if (glowBlur > 0) {
      ctx.shadowColor = strokeColor;
      ctx.shadowBlur = glowBlur;
    }
    
    const dashSize = Math.max(4, 8 * sizeFactor);
    ctx.setLineDash([dashSize, dashSize]);
    ctx.lineDashOffset = -offset;
    
    if (!geometry.path && typeof Path2D !== 'undefined') {
      geometry.path = new Path2D();
      const firstPoint = geometry.segments[0].start;
      geometry.path.moveTo(firstPoint.x, firstPoint.y);
      for (const segment of geometry.segments) geometry.path.lineTo(segment.end.x, segment.end.y);
    }

    if (geometry.path) {
      ctx.stroke(geometry.path);
    } else {
      ctx.beginPath();
      const firstPoint = geometry.segments[0].start;
      ctx.moveTo(firstPoint.x, firstPoint.y);
      for (const segment of geometry.segments) ctx.lineTo(segment.end.x, segment.end.y);
      ctx.stroke();
    }
    
    ctx.restore();
  }

  // ═══════════════════════════════════════════════
  // NEW ANIMATION STYLES
  // ═══════════════════════════════════════════════

  function drawGradientPulse(ctx, el, geometry, offset, config) {
    const strokeColor = el.strokeColor || '#1e1e1e';
    const strokeWidth = el.strokeWidth || 2;
    const totalLength = geometry.totalLength;
    if (totalLength === 0) return;
    
    ctx.save();
    const sizeFactor = (config.particleSize || 3) / 3;
    ctx.lineWidth = (strokeWidth + 2) * sizeFactor;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    const glowBlur = getGlowBlur(config);
    
    // Draw multiple gradient sweeps along the path
    const sweepLength = 80 * sizeFactor;
    const spacing = config.particleSpacing || 50;
    const sweepSpacing = Math.max(sweepLength + 20, spacing * 2);
    
    let startDist = ((offset * 1.5) % sweepSpacing);
    if (startDist < 0) startDist += sweepSpacing;
    
    while (startDist < totalLength + sweepLength) {
      // Draw a gradient segment
      const steps = Math.max(8, Math.round(20 * flowFrameBudget.sampleScale));
      const stepLen = sweepLength / steps;
      
      for (let i = 0; i < steps; i++) {
        const d1 = startDist + i * stepLen;
        const d2 = startDist + (i + 1) * stepLen;
        
        if (d1 > totalLength || d2 < 0) continue;
        
        const clampD1 = Math.max(0, Math.min(d1, totalLength));
        const clampD2 = Math.max(0, Math.min(d2, totalLength));
        
        const pt1 = getPointAtLength(geometry, clampD1);
        const pt2 = getPointAtLength(geometry, clampD2);
        
        // Fade in at start, fade out at end of sweep
        const t = i / steps;
        const alpha = Math.sin(t * Math.PI) * 0.85;
        
        if (alpha <= 0.01) continue;
        
        ctx.globalAlpha = alpha;
        ctx.strokeStyle = strokeColor;
        if (glowBlur > 0) {
          ctx.shadowColor = strokeColor;
          ctx.shadowBlur = glowBlur * alpha;
        }
        
        ctx.beginPath();
        ctx.moveTo(pt1.x, pt1.y);
        ctx.lineTo(pt2.x, pt2.y);
        ctx.stroke();
      }
      
      startDist += sweepSpacing;
    }
    
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  function drawRippleWave(ctx, el, geometry, offset, config) {
    const strokeColor = el.strokeColor || '#1e1e1e';
    const strokeWidth = el.strokeWidth || 2;
    const totalLength = geometry.totalLength;
    if (totalLength === 0) return;
    
    ctx.save();
    const sizeFactor = (config.particleSize || 3) / 3;
    const glowBlur = getGlowBlur(config);
    const spacing = config.particleSpacing || 50;
    const maxRadius = (8 + strokeWidth * 2) * sizeFactor;
    
    // Place ripple centers along the path at intervals
    let d = ((offset * 0.8) % spacing + spacing) % spacing;
    while (d < totalLength) {
      const pt = getPointAtLength(geometry, d);
      
      // Each ripple has 3 expanding rings
      for (let ring = 0; ring < 3; ring++) {
        const phase = ((offset * 0.06) + ring * 0.33) % 1;
        const radius = phase * maxRadius;
        const alpha = (1 - phase) * 0.6;
        
        if (alpha <= 0.02) continue;
        
        ctx.globalAlpha = alpha;
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = Math.max(1, (strokeWidth * 0.4) * sizeFactor * (1 - phase));
        
        if (glowBlur > 0) {
          ctx.shadowColor = strokeColor;
          ctx.shadowBlur = glowBlur * alpha;
        }
        
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, radius, 0, Math.PI * 2);
        ctx.stroke();
      }
      
      d += spacing;
    }
    
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  function drawPacketTrain(ctx, el, geometry, offset, config) {
    const strokeColor = el.strokeColor || '#1e1e1e';
    const strokeWidth = el.strokeWidth || 2;
    const totalLength = geometry.totalLength;
    if (totalLength === 0) return;
    
    ctx.save();
    const sizeFactor = (config.particleSize || 3) / 3;
    const glowBlur = getGlowBlur(config);
    const spacing = config.particleSpacing || 50;
    
    ctx.fillStyle = strokeColor;
    if (glowBlur > 0) {
      ctx.shadowColor = strokeColor;
      ctx.shadowBlur = glowBlur;
    }
    
    const packetLen = 10 * sizeFactor;
    const packetWidth = (strokeWidth + 2) * sizeFactor;
    
    let d = ((offset * 1.2) % spacing + spacing) % spacing;
    while (d < totalLength) {
      const pt = getPointAtLength(geometry, d);
      const angle = Math.atan2(pt.dy, pt.dx);
      
      ctx.save();
      ctx.translate(pt.x, pt.y);
      ctx.rotate(angle);
      
      // Draw a chevron/arrow packet shape
      ctx.beginPath();
      ctx.moveTo(packetLen / 2, 0);
      ctx.lineTo(-packetLen / 2, -packetWidth / 2);
      ctx.lineTo(-packetLen / 4, 0);
      ctx.lineTo(-packetLen / 2, packetWidth / 2);
      ctx.closePath();
      ctx.fill();
      
      ctx.restore();
      
      d += spacing;
    }
    
    ctx.restore();
  }

  function drawSnakeTrail(ctx, el, geometry, offset, config) {
    const strokeColor = el.strokeColor || '#1e1e1e';
    const strokeWidth = el.strokeWidth || 2;
    const totalLength = geometry.totalLength;
    if (totalLength === 0) return;
    
    ctx.save();
    const sizeFactor = (config.particleSize || 3) / 3;
    const glowBlur = getGlowBlur(config);
    const spacing = config.particleSpacing || 50;
    
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    // Draw tapered, fading trail segments
    const trailLength = spacing * 1.5;
    const trailSpacing = spacing * 2.5;
    const steps = Math.max(12, Math.round(30 * flowFrameBudget.sampleScale));
    const stepLen = trailLength / steps;
    
    let startDist = ((offset * 1.3) % trailSpacing + trailSpacing) % trailSpacing;
    
    while (startDist < totalLength + trailLength) {
      for (let i = 0; i < steps - 1; i++) {
        const d1 = startDist - i * stepLen;
        const d2 = startDist - (i + 1) * stepLen;
        
        if (d1 < 0 || d2 > totalLength) continue;
        
        const clampD1 = Math.max(0, Math.min(d1, totalLength));
        const clampD2 = Math.max(0, Math.min(d2, totalLength));
        
        const pt1 = getPointAtLength(geometry, clampD1);
        const pt2 = getPointAtLength(geometry, clampD2);
        
        // Taper: head is thick, tail thins out
        const taper = 1 - (i / steps);
        const alpha = taper * 0.75;
        const width = Math.max(1, (strokeWidth + 2) * sizeFactor * taper);
        
        if (alpha <= 0.02) continue;
        
        ctx.globalAlpha = alpha;
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = width;
        
        if (glowBlur > 0) {
          ctx.shadowColor = strokeColor;
          ctx.shadowBlur = glowBlur * taper;
        }
        
        ctx.beginPath();
        ctx.moveTo(pt1.x, pt1.y);
        ctx.lineTo(pt2.x, pt2.y);
        ctx.stroke();
      }
      
      startDist += trailSpacing;
    }
    
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  function drawComet(ctx, el, geometry, offset, config) {
    const color = el.strokeColor || '#1e1e1e';
    const strokeWidth = el.strokeWidth || 2;
    const length = geometry.totalLength;
    const size = (config.particleSize || 3) / 3;
    const spacing = Math.max(70, (config.particleSpacing || 50) * 2.5);
    const tailLength = Math.min(120 * size, spacing * 0.72);
    const steps = Math.max(10, Math.round(24 * flowFrameBudget.sampleScale));
    if (!length) return;

    ctx.save();
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineCap = 'round';
    let headDistance = ((offset * 1.45) % spacing + spacing) % spacing;
    while (headDistance < length + tailLength) {
      for (let step = 0; step < steps; step++) {
        const progress = step / steps;
        const d1 = headDistance - progress * tailLength;
        const d2 = headDistance - ((step + 1) / steps) * tailLength;
        if (d1 < 0 || d2 > length) continue;
        const from = getPointAtLength(geometry, Math.min(length, d1));
        const to = getPointAtLength(geometry, Math.max(0, d2));
        const strength = 1 - progress;
        ctx.globalAlpha = strength * strength * 0.8;
        ctx.lineWidth = Math.max(0.7, (strokeWidth + 3) * size * strength);
        ctx.shadowColor = color;
        ctx.shadowBlur = getGlowBlur(config) * strength;
        ctx.beginPath();
        ctx.moveTo(from.x, from.y);
        ctx.lineTo(to.x, to.y);
        ctx.stroke();
      }
      if (headDistance <= length) {
        const head = getPointAtLength(geometry, headDistance);
        ctx.globalAlpha = 1;
        ctx.shadowBlur = getGlowBlur(config) * 1.8;
        ctx.beginPath();
        ctx.arc(head.x, head.y, Math.max(2, (strokeWidth + 1.5) * size), 0, Math.PI * 2);
        ctx.fill();
      }
      headDistance += spacing;
    }
    ctx.restore();
  }

  function drawElectricity(ctx, el, geometry, offset, config) {
    const color = el.strokeColor || '#1e1e1e';
    const strokeWidth = el.strokeWidth || 2;
    const length = geometry.totalLength;
    const size = (config.particleSize || 3) / 3;
    const spacing = Math.max(70, (config.particleSpacing || 50) * 2);
    const boltLength = Math.min(100, spacing * 0.68);
    if (!length) return;

    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(1, strokeWidth * 0.8 * size);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.shadowColor = color;
    ctx.shadowBlur = getGlowBlur(config) * 1.4;
    let start = ((offset * 1.8) % spacing + spacing) % spacing;
    while (start < length) {
      const end = Math.min(length, start + boltLength);
      ctx.beginPath();
      let index = 0;
      for (let distance = start; distance <= end; distance += 7, index++) {
        const point = getPointAtLength(geometry, distance);
        const fade = Math.sin(Math.PI * (distance - start) / Math.max(1, end - start));
        const jitter = Math.sin(index * 12.9898 + Math.floor(offset / 3) * 7.23) * 5 * size * fade;
        const x = point.x - point.dy * jitter;
        const y = point.y + point.dx * jitter;
        if (index === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      start += spacing;
    }
    ctx.restore();
  }

  function drawFlowWave(ctx, el, geometry, offset, config) {
    const color = el.strokeColor || '#1e1e1e';
    const strokeWidth = el.strokeWidth || 2;
    const length = geometry.totalLength;
    const size = (config.particleSize || 3) / 3;
    const wavelength = Math.max(24, config.particleSpacing || 50);
    const amplitude = (3 + strokeWidth * 1.5) * size;
    const sampleDistance = flowFrameBudget.sampleScale < 1 ? 6 : 4;
    if (!length) return;

    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(1, strokeWidth * 0.75 * size);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.shadowColor = color;
    ctx.shadowBlur = getGlowBlur(config);
    ctx.beginPath();
    let index = 0;
    for (let distance = 0; distance <= length; distance += sampleDistance, index++) {
      const point = getPointAtLength(geometry, Math.min(distance, length));
      const displacement = Math.sin((distance - offset * 1.5) * Math.PI * 2 / wavelength) * amplitude;
      const x = point.x - point.dy * displacement;
      const y = point.y + point.dx * displacement;
      if (index === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.restore();
  }

  function drawDualFlow(ctx, el, geometry, offset, config) {
    const color = el.strokeColor || '#1e1e1e';
    const strokeWidth = el.strokeWidth || 2;
    const length = geometry.totalLength;
    const spacing = Math.max(24, config.particleSpacing || 50);
    const size = (config.particleSize || 3) / 3;
    const radius = Math.max(1.5, strokeWidth * 0.8 * size);
    const phase = ((offset % spacing) + spacing) % spacing;
    if (!length) return;

    ctx.save();
    ctx.fillStyle = color;
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(1, radius * 0.6);
    ctx.shadowColor = color;
    ctx.shadowBlur = getGlowBlur(config);
    for (let stream = 0; stream < 2; stream++) {
      let distance = stream === 0 ? phase : (spacing - phase + spacing / 2) % spacing;
      while (distance < length) {
        const point = getPointAtLength(geometry, distance);
        const laneOffset = radius * 1.5 * (stream === 0 ? 1 : -1);
        ctx.beginPath();
        ctx.arc(point.x - point.dy * laneOffset, point.y + point.dx * laneOffset, radius, 0, Math.PI * 2);
        if (stream === 0) ctx.fill();
        else ctx.stroke();
        distance += spacing;
      }
    }
    ctx.restore();
  }

  // ═══════════════════════════════════════════════
  // IN-CANVAS FLOATING TOOLBAR
  // ═══════════════════════════════════════════════

  const ANIMATION_STYLES = [
    { id: 'comet', label: 'Comet', icon: '&#9732;' },
    { id: 'electricity', label: 'Electric', icon: '∿' },
    { id: 'wave', label: 'Wave', icon: '&#8767;' },
    { id: 'dual', label: 'Dual', icon: '&#8644;' },
    { id: 'particles', label: 'Particles', icon: '●' },
    { id: 'dashes', label: 'Ants', icon: '⋯' },
    { id: 'gradient', label: 'Pulse', icon: '◐' },
    { id: 'ripple', label: 'Ripple', icon: '◎' },
    { id: 'train', label: 'Packet', icon: '▸▸' },
    { id: 'snake', label: 'Snake', icon: '∿' },
  ];

  let panelOpen = false;

  function injectToolbarStyles() {
    if (document.getElementById('excaligif-toolbar-styles')) return;

    const style = document.createElement('style');
    style.id = 'excaligif-toolbar-styles';
    style.textContent = `
      .excaligif-toolbar {
        position: fixed;
        bottom: 24px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 10000;
        display: none;
        flex-direction: column;
        align-items: center;
        gap: 6px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        user-select: none;
      }
      .excaligif-toolbar.visible {
        display: flex;
        animation: excaligif-fadeIn 0.2s ease-out;
      }
      @keyframes excaligif-fadeIn {
        from { opacity: 0; transform: translateX(-50%) translateY(8px); }
        to { opacity: 1; transform: translateX(-50%) translateY(0); }
      }
      
      /* Settings Panel above main toolbar */
      .excaligif-toolbar-panel {
        display: none;
        flex-direction: column;
        gap: 8px;
        background: rgba(18, 18, 26, 0.96);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(140, 90, 220, 0.25);
        border-radius: 14px;
        padding: 12px 14px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.45);
        animation: excaligif-slideUp 0.2s ease-out;
        width: 250px;
      }
      .excaligif-toolbar-panel.visible {
        display: flex;
      }
      @keyframes excaligif-slideUp {
        from { opacity: 0; transform: translateY(8px); }
        to { opacity: 1; transform: translateY(0); }
      }
      
      .excaligif-panel-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
      }
      .excaligif-panel-row > span {
        font-size: 10px;
        color: rgba(255,255,255,0.45);
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        width: 65px;
      }
      
      /* Pill Button Selectors */
      .excaligif-pill-group {
        display: flex;
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.06);
        border-radius: 8px;
        padding: 2px;
        flex: 1;
        justify-content: space-between;
      }
      .excaligif-pill-group button {
        background: none;
        border: none;
        color: rgba(255,255,255,0.5);
        font-family: inherit;
        font-size: 10px;
        font-weight: 600;
        padding: 4px 6px;
        cursor: pointer;
        border-radius: 6px;
        transition: all 0.15s ease;
        outline: none;
        flex: 1;
        text-align: center;
      }
      .excaligif-pill-group button:hover {
        color: rgba(255,255,255,0.85);
      }
      .excaligif-pill-group button.active {
        background: rgba(140, 90, 220, 0.25);
        border: 1px solid rgba(140, 90, 220, 0.4);
        color: hsl(270, 75%, 70%);
      }
      
      /* Range Inputs */
      .excaligif-range-group {
        display: flex;
        align-items: center;
        gap: 8px;
        flex: 1;
      }
      .excaligif-range-group input[type="range"] {
        -webkit-appearance: none;
        appearance: none;
        flex: 1;
        height: 3px;
        background: rgba(255,255,255,0.1);
        border-radius: 3px;
        outline: none;
        cursor: pointer;
      }
      .excaligif-range-group input[type="range"]::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 10px;
        height: 10px;
        background: hsl(270, 75%, 64%);
        border-radius: 50%;
        cursor: pointer;
        box-shadow: 0 0 6px hsla(270, 75%, 64%, 0.5);
      }
      .excaligif-range-group span {
        font-size: 10px;
        font-weight: 600;
        color: hsl(270, 75%, 70%);
        min-width: 20px;
        text-align: right;
      }
      
      /* Main Toolbar Bar */
      .excaligif-toolbar-main {
        display: flex;
        align-items: center;
        gap: 3px;
        max-width: calc(100vw - 24px);
        overflow-x: auto;
        scrollbar-width: none;
        background: rgba(18, 18, 26, 0.92);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(140, 90, 220, 0.25);
        border-radius: 14px;
        padding: 5px 8px;
        box-shadow: 0 4px 24px rgba(0,0,0,0.45), 0 0 16px rgba(140, 90, 220, 0.08);
      }
      .excaligif-toolbar-main::-webkit-scrollbar {
        display: none;
      }
      .excaligif-toolbar-label {
        font-size: 11px;
        font-weight: 700;
        color: rgba(255,255,255,0.92);
        padding: 0 6px 0 4px;
        letter-spacing: -0.3px;
        white-space: nowrap;
      }
      .excaligif-toolbar-label span {
        color: hsl(270, 75%, 64%);
        text-shadow: 0 0 8px hsla(270, 75%, 64%, 0.3);
      }
      .excaligif-toolbar-divider {
        width: 1px;
        height: 20px;
        background: rgba(255,255,255,0.1);
        margin: 0 3px;
      }
      .excaligif-toolbar-btn {
        display: flex;
        flex-shrink: 0;
        align-items: center;
        gap: 4px;
        padding: 5px 10px;
        border: 1px solid rgba(255,255,255,0.06);
        border-radius: 10px;
        background: rgba(255,255,255,0.04);
        color: rgba(255,255,255,0.6);
        font-family: inherit;
        font-size: 11px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.18s ease;
        white-space: nowrap;
        outline: none;
      }
      .excaligif-toolbar-btn:hover {
        background: rgba(140, 90, 220, 0.15);
        border-color: rgba(140, 90, 220, 0.3);
        color: rgba(255,255,255,0.9);
      }
      .excaligif-toolbar-btn.active {
        background: hsl(270, 75%, 64%);
        border-color: hsl(270, 75%, 64%);
        color: #fff;
        box-shadow: 0 0 12px hsla(270, 75%, 64%, 0.35);
        font-weight: 600;
      }
      .excaligif-toolbar-btn.active:hover {
        background: hsl(270, 75%, 58%);
      }
      .excaligif-toolbar-btn.gear {
        padding: 5px 8px;
        font-size: 12px;
      }
      .excaligif-toolbar-btn.gear.active {
        background: rgba(140, 90, 220, 0.2);
        border-color: rgba(140, 90, 220, 0.4);
        color: hsl(270, 75%, 70%);
      }
      .excaligif-toolbar-btn.remove {
        color: rgba(255,255,255,0.35);
        padding: 5px 8px;
        margin-left: 1px;
      }
      .excaligif-toolbar-btn.remove:hover {
        background: rgba(220, 60, 60, 0.2);
        border-color: rgba(220, 60, 60, 0.35);
        color: hsl(0, 80%, 65%);
      }
      .excaligif-toolbar-icon {
        font-size: 12px;
        line-height: 1;
      }
    `;
    document.head.appendChild(style);
  }

  function createToolbar() {
    if (toolbarElement) return;
    injectToolbarStyles();

    const toolbar = document.createElement('div');
    toolbar.className = 'excaligif-toolbar';
    toolbar.id = 'excaligif-toolbar';

    // 1. Settings Panel
    const panel = document.createElement('div');
    panel.className = 'excaligif-toolbar-panel';
    panel.id = 'excaligif-toolbar-panel';

    // Speed Row
    panel.appendChild(createPillRow('Speed', 'speed', [
      { val: 'slow', label: 'Slow' },
      { val: 'medium', label: 'Med' },
      { val: 'fast', label: 'Fast' }
    ]));

    // Direction Row
    panel.appendChild(createPillRow('Direction', 'direction', [
      { val: 'forward', label: 'Forward' },
      { val: 'reverse', label: 'Reverse' },
      { val: 'bounce', label: 'Bounce' }
    ]));

    // Glow Row
    panel.appendChild(createPillRow('Glow', 'glowIntensity', [
      { val: 'none', label: 'None' },
      { val: 'subtle', label: 'Subtle' },
      { val: 'medium', label: 'Med' },
      { val: 'strong', label: 'Strong' }
    ]));

    // Size Slider Row
    panel.appendChild(createSliderRow('Size', 'excaligif-size-input', 'excaligif-size-val', 1, 5, 3, 1, 'particleSize'));

    // Spacing Slider Row
    panel.appendChild(createSliderRow('Spacing', 'excaligif-spacing-input', 'excaligif-spacing-val', 20, 120, 50, 5, 'particleSpacing'));

    toolbar.appendChild(panel);

    // 2. Main Bar
    const mainBar = document.createElement('div');
    mainBar.className = 'excaligif-toolbar-main';

    // Logo label
    const label = document.createElement('div');
    label.className = 'excaligif-toolbar-label';
    label.innerHTML = 'Excali<span>Up</span>';
    mainBar.appendChild(label);

    // Divider
    const div1 = document.createElement('div');
    div1.className = 'excaligif-toolbar-divider';
    mainBar.appendChild(div1);

    // Style buttons
    for (const animStyle of ANIMATION_STYLES) {
      const btn = document.createElement('button');
      btn.className = 'excaligif-toolbar-btn';
      btn.dataset.style = animStyle.id;
      btn.innerHTML = '<span class="excaligif-toolbar-icon">' + animStyle.icon + '</span>' + animStyle.label;
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        onStyleButtonClick(animStyle.id);
      });
      mainBar.appendChild(btn);
    }

    // Divider
    const div2 = document.createElement('div');
    div2.className = 'excaligif-toolbar-divider';
    mainBar.appendChild(div2);

    // Gear button for tuning panel
    const gearBtn = document.createElement('button');
    gearBtn.className = 'excaligif-toolbar-btn gear';
    gearBtn.id = 'excaligif-gear-btn';
    gearBtn.textContent = '⚙️';
    gearBtn.title = 'Tune Animation';
    gearBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      panelOpen = !panelOpen;
      updateToolbarPanelVisibility();
    });
    mainBar.appendChild(gearBtn);

    // Remove button
    const removeBtn = document.createElement('button');
    removeBtn.className = 'excaligif-toolbar-btn remove';
    removeBtn.dataset.style = 'remove';
    removeBtn.textContent = '✕';
    removeBtn.title = 'Remove animation';
    removeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      onRemoveClick();
    });
    mainBar.appendChild(removeBtn);

    toolbar.appendChild(mainBar);

    document.body.appendChild(toolbar);
    toolbarElement = toolbar;
  }

  function createPillRow(labelName, settingKey, options) {
    const row = document.createElement('div');
    row.className = 'excaligif-panel-row';
    
    const span = document.createElement('span');
    span.textContent = labelName;
    row.appendChild(span);
    
    const group = document.createElement('div');
    group.className = 'excaligif-pill-group';
    group.dataset.setting = settingKey;
    
    options.forEach(opt => {
      const btn = document.createElement('button');
      btn.dataset.val = opt.val;
      btn.textContent = opt.label;
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        updateElementSetting(settingKey, opt.val);
      });
      group.appendChild(btn);
    });
    
    row.appendChild(group);
    return row;
  }

  function createSliderRow(labelName, inputId, valId, min, max, val, step, settingKey) {
    const row = document.createElement('div');
    row.className = 'excaligif-panel-row';
    
    const span = document.createElement('span');
    span.textContent = labelName;
    row.appendChild(span);
    
    const group = document.createElement('div');
    group.className = 'excaligif-range-group';
    
    const input = document.createElement('input');
    input.type = 'range';
    input.id = inputId;
    input.min = min;
    input.max = max;
    input.value = val;
    input.step = step;
    
    const valSpan = document.createElement('span');
    valSpan.id = valId;
    valSpan.textContent = val;
    
    input.addEventListener('input', (e) => {
      valSpan.textContent = e.target.value;
      updateElementSetting(settingKey, parseInt(e.target.value, 10), false);
    });
    
    group.appendChild(input);
    group.appendChild(valSpan);
    row.appendChild(group);
    return row;
  }

  function updateElementSetting(key, val, persistImmediately = true) {
    const elements = getSelectedAnimatableElements();
    if (elements.length === 0) return;

    const metadata = new Map();
    for (const element of elements) {
      const config = Core.normalizeElementConfig({
        ...(animatedElements.get(element.id) || DEFAULT_ELEMENT_CONFIG),
        [key]: val
      });
      animatedElements.set(element.id, config);
      metadata.set(element.id, config);
    }

    animatedElementsRevision++;
    saveAnimatedElements(persistImmediately);
    queueAnimationMetadata(metadata, [], persistImmediately);
    if (persistImmediately) {
      toolbarRenderSignature = '';
      updateToolbar(true);
    } else {
      toolbarRenderSignature = `${getSelectionKey(elements)}:${animatedElementsRevision}:${panelOpen}`;
    }
    reconcileFlowRuntime();
  }

  function updateToolbarPanelVisibility() {
    if (!toolbarElement) return;
    const panel = document.getElementById('excaligif-toolbar-panel');
    const gearBtn = document.getElementById('excaligif-gear-btn');
    if (!panel || !gearBtn) return;
    
    const elements = getSelectedAnimatableElements();
    const allAnimated = elements.length > 0 && elements.every((element) => animatedElements.has(element.id));
    
    if (panelOpen && allAnimated) {
      panel.classList.add('visible');
      gearBtn.classList.add('active');
    } else {
      panel.classList.remove('visible');
      gearBtn.classList.remove('active');
    }
  }

  function getSelectedAnimatableElements() {
    if (!currentApp || !currentApp.state) return [];
    const selectedIds = currentApp.state.selectedElementIds;
    if (!selectedIds) return [];

    const ids = Object.keys(selectedIds).filter(id => selectedIds[id]);
    if (ids.length === 0) return [];

    const elementsMap = getSceneElementsMap();
    return ids
      .map((id) => elementsMap.get(id))
      .filter(isAnimatableElement);
  }

  function getSelectionKey(elements) {
    return elements.map((element) => element.id).sort().join(',');
  }

  function getCommonSetting(elements, settingKey) {
    if (elements.length === 0) return null;
    const configs = elements.map((element) => animatedElements.get(element.id));
    if (configs.some((config) => !config)) return null;
    const firstValue = Core.normalizeElementConfig(configs[0])[settingKey];
    return configs.every((config) => Core.normalizeElementConfig(config)[settingKey] === firstValue)
      ? firstValue
      : null;
  }

  function updateToolbar(force = false) {
    if (!toolbarElement) return;

    const elements = getSelectedAnimatableElements();
    if (elements.length > 0) syncAnimatedElementsFromScene(elements);
    const selectionKey = getSelectionKey(elements);
    const signature = elements.length > 0 && currentSettings.flowEnabled
      ? `${selectionKey}:${animatedElementsRevision}:${panelOpen}`
      : `hidden:${currentSettings.flowEnabled}`;
    if (!force && signature === toolbarRenderSignature) return;
    toolbarRenderSignature = signature;

    if (elements.length === 0 || !currentSettings.flowEnabled) {
      if (toolbarElement.classList.contains('visible')) {
        toolbarElement.classList.remove('visible');
      }
      lastSelectedId = null;
      panelOpen = false;
      updateToolbarPanelVisibility();
      return;
    }

    // Show toolbar
    if (!toolbarElement.classList.contains('visible') || lastSelectedId !== selectionKey) {
      toolbarElement.classList.add('visible');
      lastSelectedId = selectionKey;
    }

    // Update active state on style buttons
    const allAnimated = elements.every((element) => animatedElements.has(element.id));
    const activeStyle = allAnimated ? getCommonSetting(elements, 'style') : null;

    const buttons = toolbarElement.querySelectorAll('.excaligif-toolbar-main .excaligif-toolbar-btn:not(.remove):not(.gear)');
    for (const btn of buttons) {
      btn.classList.toggle('active', btn.dataset.style === activeStyle);
    }

    const gearBtn = document.getElementById('excaligif-gear-btn');
    if (gearBtn) {
      gearBtn.style.display = allAnimated ? 'inline-block' : 'none';
      if (!allAnimated) {
        panelOpen = false;
      }
    }

    // Populate Settings Panel inputs
    if (allAnimated) {
      const firstConfig = getElementConfig(elements[0].id);

      // Update pill button groups
      updatePills('speed', getCommonSetting(elements, 'speed'));
      updatePills('direction', getCommonSetting(elements, 'direction'));
      updatePills('glowIntensity', getCommonSetting(elements, 'glowIntensity'));
      
      // Update Sliders
      const sizeInput = document.getElementById('excaligif-size-input');
      const sizeVal = document.getElementById('excaligif-size-val');
      if (sizeInput && sizeVal) {
        const commonSize = getCommonSetting(elements, 'particleSize');
        sizeInput.value = commonSize === null ? firstConfig.particleSize : commonSize;
        sizeVal.textContent = commonSize === null ? 'Mixed' : commonSize;
      }
      
      const spacingInput = document.getElementById('excaligif-spacing-input');
      const spacingVal = document.getElementById('excaligif-spacing-val');
      if (spacingInput && spacingVal) {
        const commonSpacing = getCommonSetting(elements, 'particleSpacing');
        spacingInput.value = commonSpacing === null ? firstConfig.particleSpacing : commonSpacing;
        spacingVal.textContent = commonSpacing === null ? 'Mixed' : commonSpacing;
      }
    }
    
    updateToolbarPanelVisibility();
  }

  function updatePills(settingKey, activeVal) {
    const group = toolbarElement.querySelector(`.excaligif-pill-group[data-setting="${settingKey}"]`);
    if (!group) return;
    const buttons = group.querySelectorAll('button');
    buttons.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.val === activeVal);
    });
  }

  function onStyleButtonClick(styleId) {
    const elements = getSelectedAnimatableElements();
    if (elements.length === 0) return;

    const shouldRemove = elements.every((element) => {
      const config = animatedElements.get(element.id);
      return config && config.style === styleId;
    });
    const metadata = new Map();
    const removedIds = [];

    if (shouldRemove) {
      for (const element of elements) {
        animatedElements.delete(element.id);
        geometryCache.delete(element.id);
        removedIds.push(element.id);
      }
      panelOpen = false;
    } else {
      for (const element of elements) {
        const existing = animatedElements.get(element.id);
        const config = Core.normalizeElementConfig({
          ...(existing || DEFAULT_ELEMENT_CONFIG),
          style: styleId
        });
        animatedElements.set(element.id, config);
        metadata.set(element.id, config);
      }
    }

    animatedElementsRevision++;
    toolbarRenderSignature = '';
    saveAnimatedElements(true);
    queueAnimationMetadata(metadata, removedIds, true);
    updateToolbar(true);
    reconcileRuntime();
  }

  function onRemoveClick() {
    const elements = getSelectedAnimatableElements();
    if (elements.length === 0) return;

    const removedIds = [];
    for (const element of elements) {
      animatedElements.delete(element.id);
      geometryCache.delete(element.id);
      removedIds.push(element.id);
    }
    panelOpen = false;
    animatedElementsRevision++;
    toolbarRenderSignature = '';
    saveAnimatedElements(true);
    queueAnimationMetadata(new Map(), removedIds, true);
    updateToolbar(true);
    reconcileRuntime();
  }

  // Poll for Excalidraw instance
  setInterval(checkInstance, 1000);

  // Fast poll for element selection (responsive toolbar updates)
  setInterval(() => {
    if (currentApp && !document.hidden) {
      updateToolbar();
      updateSidebarTheme();
    }
  }, 200);

  // Listen for Toggle Event from Content Script
  document.addEventListener('ExcaliGifToggleState', (e) => {
    const targetEnabled = e.detail && e.detail.enabled;
    if (typeof targetEnabled !== 'boolean' || currentSettings.gifsEnabled === targetEnabled) return;
    currentSettings.gifsEnabled = targetEnabled;

    try {
      localStorage.setItem('excaliup_settings', JSON.stringify(currentSettings));
    } catch (error) {
      console.error('[Excali Up] Error saving settings:', error);
    }

    console.log("[Excali Up] GIF playback toggled to:", targetEnabled);
    reconcileRuntime();
    refreshGifElements(new Set(activeGifs.keys()));
  });

  // Listen for Update Settings Event from Content Script
  document.addEventListener('ExcaliGifUpdateSettings', (e) => {
    const previousSettings = { ...currentSettings };
    Object.assign(currentSettings, Core.normalizeSettings(e.detail, currentSettings));

    try {
      localStorage.setItem('excaliup_settings', JSON.stringify(currentSettings));
    } catch (error) {
      console.error('[Excali Up] Error saving settings:', error);
    }

    console.log("[Excali Up] Settings updated:", currentSettings);

    reconcileRuntime();
    if (
      previousSettings.gifsEnabled !== currentSettings.gifsEnabled ||
      previousSettings.gifSpeed !== currentSettings.gifSpeed
    ) {
      if (currentSettings.gifsEnabled) {
        const now = performance.now();
        for (const player of activeGifs.values()) {
          if (player.isPlaying) player.nextFrameAt = now;
        }
        scheduleGifTick();
      }
      refreshGifElements(new Set(activeGifs.keys()));
    }

    toolbarRenderSignature = '';
    updateToolbar(true);
  });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      stopGifScheduler();
      stopOverlayLoop();
      stopAnimatedSvgOverlayLoop();
      for (const player of activeAnimatedSvgs.values()) {
        if (player.isPlaying) player.stop();
      }
      if (saveAnimatedElementsTimer) saveAnimatedElements(true);
      return;
    }

    const now = performance.now();
    for (const player of activeGifs.values()) {
      if (player.isPlaying) player.nextFrameAt = now;
    }
    reconcileRuntime();
    updateToolbar(true);
  });

  // Listen for Query Status Event from Content Script
  document.addEventListener('ExcaliGifQueryStatus', () => {
    const reply = {
      connected: !!currentApp,
      enabled: currentSettings.gifsEnabled,
      activeGifCount: activeGifs.size,
      activeAnimatedSvgCount: activeAnimatedSvgs.size,
      animatedElementCount: animatedElements.size,
      settings: { ...currentSettings }
    };
    document.dispatchEvent(new CustomEvent('ExcaliGifStatusResponse', { detail: reply }));
  });

  window.addEventListener('pagehide', () => {
    if (saveAnimatedElementsTimer) saveAnimatedElements(true);
    if (currentApp) detachCurrentApp();
  });

  // ═══════════════════════════════════════════════
  // ICONIFY MATERIAL ICONS & LUCIDE INTEGRATION
  // ═══════════════════════════════════════════════

  function injectSidebarStyles() {
    if (document.getElementById('excaligif-sidebar-styles')) return;
    const style = document.createElement('style');
    style.id = 'excaligif-sidebar-styles';
    style.textContent = `
      .excaligif-icon-card .excaligif-icon-glyph {
        font-size: 28px;
        margin-bottom: 4px;
        color: rgba(255, 255, 255, 0.85);
        transition: transform 0.22s cubic-bezier(0.25, 0.8, 0.25, 1), color 0.22s ease;
        display: inline-flex;
        line-height: 1;
        text-transform: none;
        letter-spacing: normal;
        word-wrap: normal;
        white-space: nowrap;
        direction: ltr;
        -webkit-font-smoothing: antialiased;
        text-rendering: optimizeLegibility;
        -moz-osx-font-smoothing: grayscale;
      }

      /* Sidebar button (Dark Mode / Default) */
      .excaligif-icons-btn {
        position: absolute;
        bottom: 72px;
        right: 20px;
        width: 44px;
        height: 44px;
        border-radius: 50%;
        background: #1e1e24;
        border: 1px solid rgba(255, 255, 255, 0.15);
        color: #fff;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15), 0 0 8px rgba(140, 90, 220, 0.08);
        cursor: pointer;
        z-index: 9999;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        outline: none;
      }
      .excaligif-icons-btn iconify-icon {
        font-size: 22px;
      }
      .excaligif-icons-btn:hover {
        transform: translateY(-2px) scale(1.05);
        box-shadow: 0 6px 16px rgba(140, 90, 220, 0.25), 0 0 12px rgba(140, 90, 220, 0.15);
        border-color: rgba(140, 90, 220, 0.5);
        color: hsl(270, 75%, 70%);
      }
      .excaligif-icons-btn.active {
        background: hsl(270, 75%, 64%);
        border-color: hsl(270, 75%, 64%);
        color: #fff;
        box-shadow: 0 0 16px hsla(270, 75%, 64%, 0.45);
      }

      /* Sidebar button (Light Mode Override) */
      .excaligif-icons-btn.theme--light {
        background: #ffffff;
        border-color: rgba(0, 0, 0, 0.15);
        color: #333333;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
      }
      .excaligif-icons-btn.theme--light:hover {
        border-color: rgba(140, 90, 220, 0.4);
        color: hsl(270, 75%, 45%);
        box-shadow: 0 6px 16px rgba(140, 90, 220, 0.15);
      }
      .excaligif-icons-btn.theme--light.active {
        background: hsl(270, 75%, 64%);
        border-color: hsl(270, 75%, 64%);
        color: #fff;
        box-shadow: 0 0 16px hsla(270, 75%, 64%, 0.3);
      }

      /* Sidebar panel (Dark Mode / Default) */
      .excaligif-icons-sidebar {
        position: absolute;
        top: 0;
        right: -330px;
        width: 320px;
        height: 100%;
        background: rgba(20, 20, 28, 0.94);
        border-left: 1px solid rgba(255, 255, 255, 0.08);
        box-shadow: -4px 0 24px rgba(0,0,0,0.45);
        z-index: 10001;
        display: flex;
        flex-direction: column;
        transition: right 0.28s cubic-bezier(0.16, 1, 0.3, 1);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif;
        color: rgba(255, 255, 255, 0.9);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
      }
      .excaligif-icons-sidebar.open {
        right: 0;
      }

      .excaligif-icons-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 16px 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.06);
      }
      .excaligif-icons-header h3 {
        margin: 0;
        font-size: 16px;
        font-weight: 600;
        letter-spacing: -0.2px;
        background: linear-gradient(135deg, #fff 30%, hsl(270, 75%, 70%) 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }
      .excaligif-icons-header-actions {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .excaligif-icons-coffee {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 6px 8px;
        border: 1px solid rgba(245, 158, 66, 0.35);
        border-radius: 8px;
        background: rgba(245, 158, 66, 0.08);
        color: hsl(35, 90%, 72%);
        font-size: 10px;
        font-weight: 700;
        text-decoration: none;
        white-space: nowrap;
        transition: background 0.15s ease, border-color 0.15s ease;
      }
      .excaligif-icons-coffee:hover {
        background: rgba(245, 158, 66, 0.16);
        border-color: rgba(245, 158, 66, 0.6);
      }
      .excaligif-icons-coffee iconify-icon {
        font-size: 13px;
      }
      .excaligif-icons-close {
        background: none;
        border: none;
        color: rgba(255, 255, 255, 0.4);
        font-size: 16px;
        cursor: pointer;
        padding: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        width: 28px;
        height: 28px;
        transition: all 0.15s ease;
      }
      .excaligif-icons-close:hover {
        background: rgba(255, 255, 255, 0.08);
        color: rgba(255, 255, 255, 0.9);
      }

      .excaligif-icons-controls {
        padding: 14px 20px;
        display: flex;
        flex-direction: column;
        gap: 12px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.06);
      }

      .excaligif-icons-filters {
        display: grid;
        grid-template-columns: 1.5fr 1fr 1fr;
        gap: 8px;
      }
      .excaligif-icons-filter {
        display: flex;
        flex-direction: column;
        gap: 4px;
        min-width: 0;
      }
      .excaligif-icons-filter label {
        color: rgba(255, 255, 255, 0.38);
        font-size: 9px;
        font-weight: 700;
        letter-spacing: 0.45px;
        text-transform: uppercase;
      }
      .excaligif-icons-filter select {
        width: 100%;
        min-width: 0;
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 8px;
        color: rgba(255, 255, 255, 0.82);
        font-family: inherit;
        font-size: 11px;
        padding: 7px 8px;
        outline: none;
      }
      .excaligif-icons-filter select:focus {
        border-color: hsla(270, 75%, 64%, 0.5);
      }
      .excaligif-icons-filter option {
        background: #24242b;
        color: #fff;
      }

      .excaligif-icons-segmented {
        display: flex;
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.06);
        border-radius: 10px;
        padding: 2px;
      }
      .excaligif-icons-segmented button {
        flex: 1;
        background: none;
        border: none;
        color: rgba(255, 255, 255, 0.5);
        font-family: inherit;
        font-size: 12px;
        font-weight: 600;
        padding: 6px;
        cursor: pointer;
        border-radius: 8px;
        transition: all 0.2s ease;
        outline: none;
      }
      .excaligif-icons-segmented button.active {
        background: rgba(140, 90, 220, 0.2);
        border: 1px solid rgba(140, 90, 220, 0.35);
        color: hsl(270, 75%, 70%);
      }
      #excaligif-icons-favorite-count {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 18px;
        height: 18px;
        margin-left: 4px;
        padding: 0 5px;
        border-radius: 9px;
        background: rgba(255, 255, 255, 0.08);
        font-size: 10px;
      }

      .excaligif-icons-styles {
        display: flex;
        gap: 4px;
        flex-wrap: wrap;
      }
      .excaligif-icons-styles button {
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.05);
        color: rgba(255, 255, 255, 0.55);
        font-family: inherit;
        font-size: 11px;
        font-weight: 500;
        padding: 4px 8px;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.15s ease;
        outline: none;
      }
      .excaligif-icons-styles button:hover {
        background: rgba(255, 255, 255, 0.07);
        color: rgba(255, 255, 255, 0.85);
      }
      .excaligif-icons-styles button.active {
        background: rgba(140, 90, 220, 0.15);
        border-color: rgba(140, 90, 220, 0.35);
        color: hsl(270, 75%, 70%);
        font-weight: 600;
      }

      .excaligif-icons-search-container {
        display: flex;
        align-items: center;
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.06);
        border-radius: 10px;
        padding: 6px 12px;
        gap: 8px;
        transition: border-color 0.2s ease;
      }
      .excaligif-icons-search-container:focus-within {
        border-color: hsla(270, 75%, 64%, 0.5);
        box-shadow: 0 0 8px hsla(270, 75%, 64%, 0.15);
      }
      .excaligif-icons-search-container input {
        flex: 1;
        background: none;
        border: none;
        color: #fff;
        font-family: inherit;
        font-size: 13px;
        outline: none;
      }
      .excaligif-icons-search-container input::placeholder {
        color: rgba(255, 255, 255, 0.35);
      }
      .excaligif-icons-search-container .search-icon {
        color: rgba(255, 255, 255, 0.3);
        font-size: 13px;
      }
      .excaligif-icons-search-container button {
        background: none;
        border: none;
        color: rgba(255, 255, 255, 0.3);
        cursor: pointer;
        font-size: 12px;
        padding: 0;
        display: none;
      }
      .excaligif-icons-search-container button.visible {
        display: block;
      }
      .excaligif-icons-search-container button:hover {
        color: #fff;
      }

      .excaligif-icons-categories-container {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .category-arrows-hint {
        font-size: 9px;
        color: rgba(255, 255, 255, 0.3);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        text-align: right;
      }
      .excaligif-icons-categories {
        display: flex;
        gap: 6px;
        overflow-x: auto;
        scrollbar-width: none;
        padding: 2px 0;
      }
      .excaligif-icons-categories::-webkit-scrollbar {
        display: none;
      }
      .excaligif-category-pill {
        flex-shrink: 0;
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.05);
        color: rgba(255, 255, 255, 0.5);
        font-family: inherit;
        font-size: 11px;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 12px;
        cursor: pointer;
        transition: all 0.18s ease;
        outline: none;
      }
      .excaligif-category-pill:hover {
        background: rgba(255, 255, 255, 0.06);
        color: rgba(255, 255, 255, 0.85);
      }
      .excaligif-category-pill.active {
        background: rgba(140, 90, 220, 0.15);
        border-color: rgba(140, 90, 220, 0.45);
        color: hsl(270, 75%, 70%);
      }

      /* Grid and Cards (Dark / Default) */
      .excaligif-icons-grid {
        flex: 1;
        overflow-y: auto;
        padding: 16px 20px;
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(76px, 1fr));
        gap: 12px;
      }
      .excaligif-icons-grid::-webkit-scrollbar {
        width: 6px;
      }
      .excaligif-icons-grid::-webkit-scrollbar-track {
        background: transparent;
      }
      .excaligif-icons-grid::-webkit-scrollbar-thumb {
        background: rgba(255, 255, 255, 0.08);
        border-radius: 3px;
      }
      .excaligif-icons-grid::-webkit-scrollbar-thumb:hover {
        background: rgba(255, 255, 255, 0.15);
      }

      .excaligif-icon-card {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: space-between;
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.05);
        border-radius: 12px;
        padding: 14px 6px;
        height: 82px;
        box-sizing: border-box;
        cursor: grab;
        transition: all 0.22s cubic-bezier(0.25, 0.8, 0.25, 1);
        text-align: center;
        position: relative;
        overflow: hidden;
      }
      .excaligif-icon-card:active {
        cursor: grabbing;
      }
      .excaligif-icon-favorite {
        position: absolute;
        top: 4px;
        right: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 24px;
        height: 24px;
        padding: 0;
        border: none;
        border-radius: 7px;
        background: transparent;
        color: rgba(255, 255, 255, 0.3);
        cursor: pointer;
        opacity: 0;
        transition: opacity 0.15s ease, color 0.15s ease, background 0.15s ease;
        z-index: 1;
      }
      .excaligif-icon-card:hover .excaligif-icon-favorite,
      .excaligif-icon-favorite:focus-visible,
      .excaligif-icon-favorite.active {
        opacity: 1;
      }
      .excaligif-icon-favorite:hover {
        color: hsl(45, 95%, 65%);
        background: rgba(255, 255, 255, 0.08);
      }
      .excaligif-icon-favorite.active {
        color: hsl(45, 95%, 60%);
      }
      .excaligif-icon-favorite iconify-icon {
        font-size: 15px;
      }
      .excaligif-icon-card span.icon-name {
        font-size: 9.5px;
        line-height: 1.2;
        color: rgba(255, 255, 255, 0.45);
        width: 100%;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
        padding: 0 4px;
        word-break: break-word;
        margin-top: auto;
      }
      .excaligif-icon-card:hover {
        background: rgba(140, 90, 220, 0.12);
        border-color: rgba(140, 90, 220, 0.45);
        transform: translateY(-3px);
        box-shadow: 0 6px 14px rgba(140, 90, 220, 0.12);
      }
      .excaligif-icon-card:hover .excaligif-icon-glyph {
        transform: scale(1.15);
        color: hsl(270, 75%, 70%);
      }
      .excaligif-icon-card:hover span.icon-name {
        color: rgba(255, 255, 255, 0.8);
      }

      .excaligif-icons-loading, .excaligif-icons-error, .excaligif-icons-empty {
        grid-column: 1 / -1;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 60px 20px;
        color: rgba(255, 255, 255, 0.4);
        font-size: 13px;
        text-align: center;
        gap: 12px;
      }
      .excaligif-icons-loading .spinner {
        width: 24px;
        height: 24px;
        border: 2px solid rgba(255, 255, 255, 0.1);
        border-top-color: hsl(270, 75%, 64%);
        border-radius: 50%;
        animation: excaligif-spin 0.8s linear infinite;
      }
      @keyframes excaligif-spin {
        to { transform: rotate(360deg); }
      }

      /* Pagination Bar (Dark / Default) */
      .excaligif-icons-pagination {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 20px;
        border-top: 1px solid rgba(255, 255, 255, 0.05);
        background: rgba(0, 0, 0, 0.12);
      }
      .excaligif-page-btn {
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 8px;
        color: rgba(255, 255, 255, 0.85);
        cursor: pointer;
        padding: 6px 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s;
        outline: none;
      }
      .excaligif-page-btn:hover:not(:disabled) {
        background: rgba(140, 90, 220, 0.15);
        border-color: rgba(140, 90, 220, 0.45);
        color: hsl(270, 75%, 70%);
      }
      .excaligif-page-btn:disabled {
        opacity: 0.25;
        cursor: not-allowed;
      }
      .excaligif-page-info {
        font-size: 11.5px;
        font-weight: 600;
        color: rgba(255, 255, 255, 0.6);
        letter-spacing: 0.2px;
      }

      .excaligif-icons-footer {
        padding: 12px 20px;
        background: rgba(0, 0, 0, 0.15);
        border-top: 1px solid rgba(255, 255, 255, 0.05);
        font-size: 10px;
        color: rgba(255, 255, 255, 0.35);
        text-align: center;
        font-weight: 500;
        letter-spacing: 0.2px;
      }

      .excaligif-toast {
        position: fixed;
        bottom: 84px;
        left: 50%;
        transform: translateX(-50%) translateY(20px);
        background: rgba(140, 90, 220, 0.95);
        color: white;
        padding: 8px 16px;
        border-radius: 20px;
        font-size: 13px;
        font-weight: 500;
        box-shadow: 0 4px 16px rgba(140, 90, 220, 0.4);
        z-index: 10002;
        opacity: 0;
        pointer-events: none;
        transition: all 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      }
      .excaligif-toast.show {
        transform: translateX(-50%) translateY(0);
        opacity: 1;
      }

      /* LIGHT THEME OVERRIDES (Sidebar) */
      .excaligif-icons-sidebar.theme--light {
        background: rgba(255, 255, 255, 0.97);
        border-left: 1px solid rgba(0, 0, 0, 0.08);
        box-shadow: -4px 0 24px rgba(0,0,0,0.12);
        color: #212529;
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-header {
        border-bottom-color: rgba(0, 0, 0, 0.06);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-header h3 {
        background: linear-gradient(135deg, #121212 30%, hsl(270, 75%, 45%) 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-coffee {
        background: rgba(210, 120, 30, 0.06);
        border-color: rgba(190, 100, 20, 0.25);
        color: hsl(30, 75%, 38%);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-coffee:hover {
        background: rgba(210, 120, 30, 0.12);
        border-color: rgba(190, 100, 20, 0.45);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-close {
        color: rgba(0, 0, 0, 0.4);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-close:hover {
        background: rgba(0, 0, 0, 0.05);
        color: rgba(0, 0, 0, 0.8);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-controls {
        border-bottom-color: rgba(0, 0, 0, 0.06);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-filter label {
        color: rgba(0, 0, 0, 0.42);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-filter select {
        background: rgba(0, 0, 0, 0.025);
        border-color: rgba(0, 0, 0, 0.08);
        color: rgba(0, 0, 0, 0.78);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-filter option {
        background: #fff;
        color: #212529;
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-segmented {
        background: rgba(0, 0, 0, 0.03);
        border-color: rgba(0, 0, 0, 0.05);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-segmented button {
        color: rgba(0, 0, 0, 0.45);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-segmented button.active {
        background: #ffffff;
        border-color: rgba(140, 90, 220, 0.25);
        color: hsl(270, 75%, 45%);
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-styles button {
        background: rgba(0, 0, 0, 0.02);
        border-color: rgba(0, 0, 0, 0.04);
        color: rgba(0, 0, 0, 0.55);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-styles button:hover {
        background: rgba(0, 0, 0, 0.05);
        color: rgba(0, 0, 0, 0.8);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-styles button.active {
        background: rgba(140, 90, 220, 0.08);
        border-color: rgba(140, 90, 220, 0.3);
        color: hsl(270, 75%, 45%);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-search-container {
        background: rgba(0, 0, 0, 0.02);
        border-color: rgba(0, 0, 0, 0.06);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-search-container input {
        color: #121212;
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-search-container input::placeholder {
        color: rgba(0, 0, 0, 0.35);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-search-container .search-icon {
        color: rgba(0, 0, 0, 0.3);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-search-container button {
        color: rgba(0, 0, 0, 0.3);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-search-container button:hover {
        color: #000;
      }
      .excaligif-icons-sidebar.theme--light .category-arrows-hint {
        color: rgba(0, 0, 0, 0.35);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-category-pill {
        background: rgba(0, 0, 0, 0.02);
        border-color: rgba(0, 0, 0, 0.04);
        color: rgba(0, 0, 0, 0.5);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-category-pill:hover {
        background: rgba(0, 0, 0, 0.05);
        color: rgba(0, 0, 0, 0.8);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-category-pill.active {
        background: rgba(140, 90, 220, 0.08);
        border-color: rgba(140, 90, 220, 0.35);
        color: hsl(270, 75%, 45%);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-grid::-webkit-scrollbar-thumb {
        background: rgba(0, 0, 0, 0.08);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-grid::-webkit-scrollbar-thumb:hover {
        background: rgba(0, 0, 0, 0.15);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icon-card {
        background: rgba(0, 0, 0, 0.015);
        border-color: rgba(0, 0, 0, 0.04);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icon-card .excaligif-icon-glyph {
        color: rgba(0, 0, 0, 0.75);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icon-card span.icon-name {
        color: rgba(0, 0, 0, 0.45);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icon-favorite {
        color: rgba(0, 0, 0, 0.3);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icon-favorite:hover,
      .excaligif-icons-sidebar.theme--light .excaligif-icon-favorite.active {
        color: hsl(40, 90%, 42%);
        background: rgba(0, 0, 0, 0.05);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icon-card:hover {
        background: rgba(140, 90, 220, 0.06);
        border-color: rgba(140, 90, 220, 0.3);
        box-shadow: 0 6px 14px rgba(140, 90, 220, 0.08);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icon-card:hover .excaligif-icon-glyph {
        color: hsl(270, 75%, 45%);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icon-card:hover span.icon-name {
        color: rgba(0, 0, 0, 0.85);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-loading, 
      .excaligif-icons-sidebar.theme--light .excaligif-icons-error, 
      .excaligif-icons-sidebar.theme--light .excaligif-icons-empty {
        color: rgba(0, 0, 0, 0.45);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-loading .spinner {
        border-color: rgba(0, 0, 0, 0.08);
        border-top-color: hsl(270, 75%, 45%);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-icons-footer {
        background: rgba(0, 0, 0, 0.02);
        border-top-color: rgba(0, 0, 0, 0.05);
        color: rgba(0, 0, 0, 0.45);
      }

      /* Light Mode Overrides (Pagination) */
      .excaligif-icons-sidebar.theme--light .excaligif-icons-pagination {
        border-top-color: rgba(0, 0, 0, 0.05);
        background: rgba(0, 0, 0, 0.015);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-page-btn {
        background: rgba(0, 0, 0, 0.02);
        border-color: rgba(0, 0, 0, 0.05);
        color: rgba(0, 0, 0, 0.65);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-page-btn:hover:not(:disabled) {
        background: rgba(140, 90, 220, 0.08);
        border-color: rgba(140, 90, 220, 0.35);
        color: hsl(270, 75%, 45%);
      }
      .excaligif-icons-sidebar.theme--light .excaligif-page-info {
        color: rgba(0, 0, 0, 0.55);
      }
    `;
    document.head.appendChild(style);
  }

  function removeSidebarElements() {
    clearTimeout(iconSearchTimer);
    if (iconFetchController) iconFetchController.abort();
    iconFetchController = null;
    if (sidebarButton) {
      sidebarButton.remove();
      sidebarButton = null;
    }
    if (sidebarElement) {
      sidebarElement.remove();
      sidebarElement = null;
    }
    const styles = document.getElementById('excaligif-sidebar-styles');
    if (styles) styles.remove();
    // Remove drop listeners
    const canvas = document.querySelector('.excalidraw__canvas.interactive');
    if (canvas) {
      canvas.removeEventListener('dragover', onCanvasDragOver);
      canvas.removeEventListener('drop', onCanvasDrop);
    }
    
    document.removeEventListener('keydown', onKeyDown);
  }

  function createSidebarButtonAndPanel() {
    const excalidraw = document.querySelector('.excalidraw');
    if (!excalidraw) return;

    // Avoid duplicate initialization
    if (document.getElementById('excaligif-icons-sidebar')) return;

    injectSidebarStyles();

    // 1. Create Floating Toggle Button
    sidebarButton = document.createElement('button');
    sidebarButton.id = 'excaligif-icons-btn';
    sidebarButton.className = 'excaligif-icons-btn';
    sidebarButton.setAttribute('title', 'Iconify Icon Library (B)');
    sidebarButton.innerHTML = '<iconify-icon icon="lucide:grid-3x3" aria-hidden="true"></iconify-icon>';
    excalidraw.appendChild(sidebarButton);

    // 2. Create Sidebar Element
    sidebarElement = document.createElement('div');
    sidebarElement.id = 'excaligif-icons-sidebar';
    sidebarElement.className = 'excaligif-icons-sidebar';
    sidebarElement.innerHTML = `
      <div class="excaligif-icons-header">
        <h3>Iconify Library</h3>
        <div class="excaligif-icons-header-actions">
          <a class="excaligif-icons-coffee" href="https://donate.stripe.com/4gMdRa7XW6dt8Ph9KX9Ve01" target="_blank" rel="noopener noreferrer">
            <iconify-icon icon="lucide:coffee" aria-hidden="true"></iconify-icon>
            <span>Buy me a coffee</span>
          </a>
        <button class="excaligif-icons-close" id="excaligif-icons-close">✕</button>
        </div>
      </div>
      
      <div class="excaligif-icons-controls">
        <div class="excaligif-icons-segmented" id="excaligif-icons-view">
          <button type="button" class="active" data-view="browse" aria-pressed="true">All icons</button>
          <button type="button" data-view="favorites" aria-pressed="false">
            Favorites <span id="excaligif-icons-favorite-count">0</span>
          </button>
        </div>
        <div class="excaligif-icons-search-container">
          <iconify-icon icon="lucide:search" aria-hidden="true"></iconify-icon>
          <input type="text" id="excaligif-icons-search" placeholder="Search 300,000+ icons...">
          <button id="excaligif-icons-search-clear">✕</button>
        </div>
        
        <div class="excaligif-icons-filters">
          <div class="excaligif-icons-filter">
            <label for="excaligif-icons-pack">Icon pack</label>
            <select id="excaligif-icons-pack"><option value="">All packs</option></select>
          </div>
          <div class="excaligif-icons-filter">
            <label for="excaligif-icons-category">Category</label>
            <select id="excaligif-icons-category"><option value="">All categories</option></select>
          </div>
          <div class="excaligif-icons-filter">
            <label for="excaligif-icons-tag">Tag</label>
            <select id="excaligif-icons-tag"><option value="">All tags</option></select>
          </div>
        </div>
      </div>
      
      <div class="excaligif-icons-grid" id="excaligif-icons-grid">
        <div class="excaligif-icons-loading">
          <div class="spinner"></div>
          <span>Loading library...</span>
        </div>
      </div>

      <div class="excaligif-icons-pagination" id="excaligif-icons-pagination"></div>
      
      <div class="excaligif-icons-footer" id="excaligif-icons-footer">
        Click to copy & paste, or drag to canvas
      </div>
    `;
    excalidraw.appendChild(sidebarElement);

    // Set up canvas drop interception
    setupCanvasDropIntercept();

    // 3. Register Event Listeners
    sidebarButton.addEventListener('click', () => {
      toggleSidebar();
    });

    const closeBtn = sidebarElement.querySelector('#excaligif-icons-close');
    closeBtn.addEventListener('click', () => {
      closeSidebar();
    });

    const searchInput = sidebarElement.querySelector('#excaligif-icons-search');
    const searchClear = sidebarElement.querySelector('#excaligif-icons-search-clear');
    const packSelect = sidebarElement.querySelector('#excaligif-icons-pack');
    const categorySelect = sidebarElement.querySelector('#excaligif-icons-category');
    const tagSelect = sidebarElement.querySelector('#excaligif-icons-tag');
    const viewButtons = sidebarElement.querySelectorAll('#excaligif-icons-view button');

    viewButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const nextView = button.dataset.view;
        if (nextView === iconView) return;
        clearTimeout(iconSearchTimer);
        iconView = nextView;
        currentPage = 1;
        updateIconViewControls();
        loadIconResults();
      });
    });

    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.trim();
      currentPage = 1;
      if (searchQuery) {
        searchClear.classList.add('visible');
      } else {
        searchClear.classList.remove('visible');
      }
      clearTimeout(iconSearchTimer);
      iconSearchTimer = setTimeout(loadIconResults, 300);
    });

    searchClear.addEventListener('click', () => {
      searchInput.value = '';
      searchQuery = '';
      currentPage = 1;
      searchClear.classList.remove('visible');
      clearTimeout(iconSearchTimer);
      loadIconResults();
      searchInput.focus();
    });

    packSelect.addEventListener('change', () => {
      clearTimeout(iconSearchTimer);
      activePrefix = packSelect.value;
      currentPage = 1;
      loadIconResults();
    });

    categorySelect.addEventListener('change', () => {
      clearTimeout(iconSearchTimer);
      activeCategory = categorySelect.value;
      activePrefix = '';
      currentPage = 1;
      renderCollectionFilters();
      loadIconResults();
    });

    tagSelect.addEventListener('change', () => {
      clearTimeout(iconSearchTimer);
      activeTag = tagSelect.value;
      activePrefix = '';
      currentPage = 1;
      renderCollectionFilters();
      loadIconResults();
    });

    // Arrow navigation & general keyboard handling
    document.addEventListener('keydown', onKeyDown, true);

    updateIconViewControls();
    updateSidebarTheme();
  }

  function updateIconViewControls() {
    if (!sidebarElement) return;
    const isFavorites = iconView === 'favorites';
    for (const button of sidebarElement.querySelectorAll('#excaligif-icons-view button')) {
      const isActive = button.dataset.view === iconView;
      button.classList.toggle('active', isActive);
      button.setAttribute('aria-pressed', String(isActive));
    }
    const favoriteCount = sidebarElement.querySelector('#excaligif-icons-favorite-count');
    if (favoriteCount) favoriteCount.textContent = String(favoriteIcons.size);
    const filters = sidebarElement.querySelector('.excaligif-icons-filters');
    if (filters) filters.style.display = isFavorites ? 'none' : 'grid';
    const searchInput = sidebarElement.querySelector('#excaligif-icons-search');
    if (searchInput) {
      searchInput.placeholder = isFavorites ? 'Search favorite icons...' : 'Search 300,000+ icons...';
    }
  }

  function onKeyDown(e) {
    if (!sidebarElement) return;
    if (e.key === 'Escape' && sidebarElement.classList.contains('open')) {
      e.preventDefault();
      closeSidebar();
      return;
    }

    const target = e.target;
    const isEditable = target && (
      /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName) ||
      target.isContentEditable ||
      (typeof target.closest === 'function' && target.closest('[contenteditable="true"]'))
    );
    if (
      e.key.toLowerCase() === 'b' &&
      !e.repeat &&
      !e.ctrlKey &&
      !e.metaKey &&
      !e.altKey &&
      !isEditable
    ) {
      e.preventDefault();
      e.stopPropagation();
      toggleSidebar();
    }
  }

  function getMatchingCollections() {
    if (!iconCollections) return [];
    return Object.entries(iconCollections).filter(([, info]) => {
      if (activeCategory === '__animated__' && !(info.tags || []).includes('Contains Animations')) return false;
      if (activeCategory && activeCategory !== '__animated__' && info.category !== activeCategory) return false;
      if (activeTag && !(info.tags || []).includes(activeTag)) return false;
      return true;
    });
  }

  function setSelectOptions(select, firstLabel, entries, selectedValue) {
    if (!select) return;
    select.innerHTML = '';
    const first = document.createElement('option');
    first.value = '';
    first.textContent = firstLabel;
    select.appendChild(first);
    entries.forEach(([value, label]) => {
      const option = document.createElement('option');
      option.value = value;
      option.textContent = label;
      select.appendChild(option);
    });
    select.value = selectedValue;
  }

  function renderCollectionFilters() {
    if (!iconCollections || !sidebarElement) return;
    const allCollections = Object.values(iconCollections);
    const categories = [...new Set(allCollections.map(info => info.category).filter(Boolean))].sort();
    const categoryOptions = [
      ['__animated__', 'Animated SVG'],
      ...categories.map(value => [value, value])
    ];
    const tags = [...new Set(allCollections.flatMap(info => info.tags || []))].sort();
    const packs = getMatchingCollections().sort((a, b) => a[1].name.localeCompare(b[1].name));

    setSelectOptions(
      sidebarElement.querySelector('#excaligif-icons-category'),
      'All categories',
      categoryOptions,
      activeCategory
    );
    setSelectOptions(
      sidebarElement.querySelector('#excaligif-icons-tag'),
      'All tags',
      tags.map(value => [value, value]),
      activeTag
    );
    setSelectOptions(
      sidebarElement.querySelector('#excaligif-icons-pack'),
      `All packs (${packs.length})`,
      packs.map(([prefix, info]) => [prefix, `${info.name} (${(info.total || 0).toLocaleString()})`]),
      activePrefix
    );
  }

  function createIconResult(iconifyName) {
    const separator = iconifyName.indexOf(':');
    if (separator < 1) return null;
    const prefix = iconifyName.slice(0, separator);
    const name = iconifyName.slice(separator + 1);
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(prefix) || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(name)) {
      return null;
    }
    return {
      icon: iconifyName,
      name,
      prefix,
      collection: iconCollections && iconCollections[prefix]
    };
  }

  function getFilteredFavoriteIconNames() {
    const normalizedQuery = searchQuery.trim().toLowerCase();
    return [...favoriteIcons].filter(iconName => {
      if (!normalizedQuery) return true;
      return iconName.toLowerCase().includes(normalizedQuery) ||
        iconName.replace(/[-_:]/g, ' ').toLowerCase().includes(normalizedQuery);
    });
  }

  async function loadIconCollections() {
    if (iconCollections) return loadIconResults();
    if (iconCollectionsPromise) return iconCollectionsPromise;
    const grid = document.getElementById('excaligif-icons-grid');
    if (grid) {
      grid.innerHTML = '<div class="excaligif-icons-loading"><div class="spinner"></div><span>Loading Iconify collections...</span></div>';
    }
    iconCollectionsPromise = (async () => {
      try {
        const response = await fetch('https://api.iconify.design/collections');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        iconCollections = await response.json();
        renderCollectionFilters();
        await loadIconResults();
      } catch (error) {
        console.error('[Excali Up] Failed to load Iconify collections:', error);
        if (grid) grid.innerHTML = '<div class="excaligif-icons-error">Failed to load Iconify collections.</div>';
      } finally {
        iconCollectionsPromise = null;
      }
    })();
    return iconCollectionsPromise;
  }

  async function loadIconResults() {
    if (!iconCollections) return loadIconCollections();
    if (iconFetchController) iconFetchController.abort();
    const fetchController = new AbortController();
    iconFetchController = fetchController;
    const requestId = ++iconRequestId;
    const grid = document.getElementById('excaligif-icons-grid');
    if (grid) {
      grid.innerHTML = '<div class="excaligif-icons-loading"><div class="spinner"></div><span>Loading icons...</span></div>';
    }

    try {
      let iconNames = [];
      const matchingCollections = getMatchingCollections();

      if (iconView === 'favorites') {
        iconNames = getFilteredFavoriteIconNames();
      } else if (searchQuery) {
        const url = new URL('https://api.iconify.design/search');
        url.searchParams.set('query', searchQuery);
        url.searchParams.set('limit', '999');
        if (activePrefix) {
          url.searchParams.set('prefix', activePrefix);
        } else if (activeTag || activeCategory === '__animated__') {
          const prefixes = matchingCollections.map(([prefix]) => prefix);
          if (prefixes.length === 0) {
            if (requestId !== iconRequestId) return;
            visibleIcons = [];
            renderIconsGrid();
            return;
          }
          url.searchParams.set('prefixes', prefixes.join(','));
        } else if (activeCategory) {
          url.searchParams.set('category', activeCategory);
        }
        const response = await fetch(url, { signal: fetchController.signal });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();
        iconNames = data.icons || [];
      } else if (activePrefix) {
        const response = await fetch(`https://api.iconify.design/collection?prefix=${encodeURIComponent(activePrefix)}`, {
          signal: fetchController.signal
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();
        const names = [
          ...(data.uncategorized || []),
          ...Object.values(data.categories || {}).flat()
        ];
        iconNames = [...new Set(names)].map(name => `${activePrefix}:${name}`);
      } else {
        iconNames = matchingCollections.flatMap(([prefix, info]) =>
          (info.samples || []).map(name => `${prefix}:${name}`)
        );
      }

      if (requestId !== iconRequestId) return;
      visibleIcons = iconNames.map(createIconResult).filter(Boolean);
      renderIconsGrid();
    } catch (error) {
      if (requestId !== iconRequestId) return;
      if (error.name === 'AbortError') return;
      console.error('[Excali Up] Iconify search failed:', error);
      visibleIcons = [];
      if (grid) grid.innerHTML = '<div class="excaligif-icons-error">Failed to load icons. Try again.</div>';
      updatePaginationControls(0);
    } finally {
      if (iconFetchController === fetchController) iconFetchController = null;
    }
  }

  function renderIconsGrid() {
    const grid = document.getElementById('excaligif-icons-grid');
    if (!grid) return;

    grid.innerHTML = '';

    if (visibleIcons.length === 0) {
      grid.innerHTML = iconView === 'favorites'
        ? '<div class="excaligif-icons-empty"><iconify-icon icon="lucide:star" style="font-size:28px"></iconify-icon><span>No favorite icons yet.<br>Use the star on any icon to save it here.</span></div>'
        : '<div class="excaligif-icons-empty">No matching icons found.</div>';
      updatePaginationControls(0);
      const footer = document.getElementById('excaligif-icons-footer');
      if (footer) footer.textContent = 'Found 0 icons.';
      return;
    }

    const totalPages = Math.ceil(visibleIcons.length / pageSize) || 1;
    if (currentPage > totalPages) currentPage = totalPages;

    const startIdx = (currentPage - 1) * pageSize;
    const endIdx = startIdx + pageSize;
    const itemsToRender = visibleIcons.slice(startIdx, endIdx);

    itemsToRender.forEach((icon) => {
      const card = document.createElement('div');
      card.className = 'excaligif-icon-card';
      card.setAttribute('draggable', 'true');
      const collectionName = icon.collection ? icon.collection.name : icon.prefix;
      card.setAttribute('title', `${icon.name}\n${collectionName}\nClick to copy & paste\nDrag to canvas`);

      card.innerHTML = `
        <button type="button" class="excaligif-icon-favorite${favoriteIcons.has(icon.icon) ? ' active' : ''}" title="${favoriteIcons.has(icon.icon) ? 'Remove from favorites' : 'Add to favorites'}" aria-label="${favoriteIcons.has(icon.icon) ? 'Remove from favorites' : 'Add to favorites'}">
          <iconify-icon icon="lucide:star" aria-hidden="true"></iconify-icon>
        </button>
        <iconify-icon class="excaligif-icon-glyph" icon="${icon.icon}" aria-hidden="true"></iconify-icon>
        <span class="icon-name">${icon.name.replace(/[-_]/g, ' ')}</span>
      `;

      const favoriteButton = card.querySelector('.excaligif-icon-favorite');
      favoriteButton.setAttribute('draggable', 'false');
      favoriteButton.addEventListener('pointerdown', event => event.stopPropagation());
      favoriteButton.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (favoriteIcons.has(icon.icon)) {
          favoriteIcons.delete(icon.icon);
          showToast(`"${icon.name}" removed from favorites`);
        } else {
          favoriteIcons.add(icon.icon);
          showToast(`"${icon.name}" added to favorites`);
        }
        saveFavoriteIcons();
        updateIconViewControls();
        if (iconView === 'favorites') {
          visibleIcons = getFilteredFavoriteIconNames()
            .map(createIconResult)
            .filter(Boolean);
        }
        renderIconsGrid();
      });

      card.addEventListener('dragstart', (e) => {
        if (e.target.closest && e.target.closest('.excaligif-icon-favorite')) {
          e.preventDefault();
          return;
        }
        isDraggingIcon = true;
        draggingIconData = { name: icon.name, icon: icon.icon };
        e.dataTransfer.effectAllowed = 'copy';
        e.dataTransfer.setData('text/plain', icon.icon);
        card.style.opacity = '0.5';
      });

      card.addEventListener('dragend', () => {
        isDraggingIcon = false;
        draggingIconData = null;
        card.style.opacity = '1';
      });

      card.addEventListener('click', async () => {
        card.innerHTML = '<div class="spinner-small" style="width:16px;height:16px;border:2px solid rgba(255,255,255,0.2);border-top-color:currentColor;border-radius:50%;animation:excaligif-spin 0.6s linear infinite;margin-bottom:6px;"></div><span class="icon-name">Fetching...</span>';
        
        try {
          const svgContent = await getSvgContent(icon.icon);
          if (svgContent) {
            await navigator.clipboard.writeText(svgContent);
            showToast(`"${icon.name}" copied!`);

            queueAnimatedSvgImport(svgContent);
            const clipboardData = new DataTransfer();
            clipboardData.setData('text/plain', svgContent);
            const pasteEvent = new ClipboardEvent('paste', {
              clipboardData,
              bubbles: true,
              cancelable: true
            });
            document.activeElement.dispatchEvent(pasteEvent);
          } else {
            showToast("Failed to fetch SVG");
          }
        } catch (err) {
          console.error("[Excali Up] Copy failed:", err);
          showToast("Copy failed");
        } finally {
          renderIconsGrid();
        }
      });

      grid.appendChild(card);
    });

    updatePaginationControls(visibleIcons.length);

    const footer = document.getElementById('excaligif-icons-footer');
    if (footer) {
      const context = iconView === 'favorites'
        ? 'Favorites'
        : activePrefix && iconCollections[activePrefix]
        ? iconCollections[activePrefix].name
        : `${getMatchingCollections().length} packs`;
      const capped = searchQuery && visibleIcons.length === 999 ? 'First ' : '';
      footer.textContent = `${capped}${visibleIcons.length.toLocaleString()} icons · ${context} · Click or drag.`;
    }
  }

  function updatePaginationControls(totalItems) {
    const container = document.getElementById('excaligif-icons-pagination');
    if (!container) return;

    if (totalItems === 0) {
      container.innerHTML = '';
      return;
    }

    const totalPages = Math.ceil(totalItems / pageSize) || 1;
    if (currentPage > totalPages) currentPage = totalPages;

    container.innerHTML = `
      <button class="excaligif-page-btn" id="btn-page-prev" ${currentPage === 1 ? 'disabled' : ''}>
        <iconify-icon icon="lucide:chevron-left" aria-hidden="true"></iconify-icon>
      </button>
      <span class="excaligif-page-info">Page ${currentPage} of ${totalPages}</span>
      <button class="excaligif-page-btn" id="btn-page-next" ${currentPage === totalPages ? 'disabled' : ''}>
        <iconify-icon icon="lucide:chevron-right" aria-hidden="true"></iconify-icon>
      </button>
    `;

    const prevBtn = container.querySelector('#btn-page-prev');
    const nextBtn = container.querySelector('#btn-page-next');

    if (prevBtn && currentPage > 1) {
      prevBtn.addEventListener('click', () => {
        currentPage--;
        renderIconsGrid();
        const grid = document.getElementById('excaligif-icons-grid');
        if (grid) grid.scrollTop = 0;
      });
    }

    if (nextBtn && currentPage < totalPages) {
      nextBtn.addEventListener('click', () => {
        currentPage++;
        renderIconsGrid();
        const grid = document.getElementById('excaligif-icons-grid');
        if (grid) grid.scrollTop = 0;
      });
    }
  }

  function updateSidebarTheme() {
    if (!currentApp || !sidebarElement) return;
    const theme = currentApp.state.theme || 'light';
    if (theme === 'dark') {
      sidebarElement.classList.remove('theme--light');
      sidebarElement.classList.add('theme--dark');
      if (sidebarButton) {
        sidebarButton.classList.remove('theme--light');
        sidebarButton.classList.add('theme--dark');
      }
    } else {
      sidebarElement.classList.remove('theme--dark');
      sidebarElement.classList.add('theme--light');
      if (sidebarButton) {
        sidebarButton.classList.remove('theme--dark');
        sidebarButton.classList.add('theme--light');
      }
    }
  }

  function toggleSidebar() {
    if (!sidebarElement) return;
    const isOpen = sidebarElement.classList.contains('open');
    if (isOpen) {
      closeSidebar();
    } else {
      openSidebar();
    }
  }

  function openSidebar() {
    if (!sidebarElement || !sidebarButton) return;
    sidebarElement.classList.add('open');
    sidebarButton.classList.add('active');
    if (!iconCollections) {
      loadIconCollections();
    } else {
      renderIconsGrid();
    }
  }

  function closeSidebar() {
    if (!sidebarElement || !sidebarButton) return;
    sidebarElement.classList.remove('open');
    sidebarButton.classList.remove('active');
    clearTimeout(iconSearchTimer);
    if (iconFetchController) iconFetchController.abort();
    const grid = document.getElementById('excaligif-icons-grid');
    const pagination = document.getElementById('excaligif-icons-pagination');
    if (grid) grid.innerHTML = '';
    if (pagination) pagination.innerHTML = '';
  }

  function setupCanvasDropIntercept() {
    const canvas = document.querySelector('.excalidraw__canvas.interactive');
    if (!canvas) return;
    
    canvas.removeEventListener('dragover', onCanvasDragOver);
    canvas.removeEventListener('drop', onCanvasDrop);
    
    canvas.addEventListener('dragover', onCanvasDragOver);
    canvas.addEventListener('drop', onCanvasDrop);
  }

  function onCanvasDragOver(e) {
    if (isDraggingIcon) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
    }
  }

  async function onCanvasDrop(e) {
    if (!isDraggingIcon || !draggingIconData) return;
    e.preventDefault();
    e.stopPropagation();

    const { name, icon } = draggingIconData;
    isDraggingIcon = false;
    draggingIconData = null;

    const canvas = document.querySelector('.excalidraw__canvas.interactive');
    if (!canvas) return;

    const clientX = e.clientX;
    const clientY = e.clientY;

    try {
      showToast("Fetching SVG...");
      const svgContent = await getSvgContent(icon);
      if (!svgContent) {
        showToast("Failed to fetch SVG");
        return;
      }

      queueAnimatedSvgImport(svgContent);
      const file = new File([svgContent], `${name}.svg`, { type: 'image/svg+xml' });
      const dataTransfer = new DataTransfer();
      dataTransfer.items.add(file);

      const dropEvent = new DragEvent('drop', {
        dataTransfer,
        bubbles: true,
        cancelable: true,
        clientX,
        clientY
      });

      canvas.dispatchEvent(dropEvent);
      showToast("Icon dropped!");
    } catch (err) {
      console.error("[Excali Up] Drop failed:", err);
      showToast("Drop failed");
    }
  }

  async function getSvgContent(iconifyName) {
    if (svgCache.has(iconifyName)) {
      return svgCache.get(iconifyName);
    }

    const [prefix, iconName] = iconifyName.split(':');
    const url = `https://api.iconify.design/${encodeURIComponent(prefix)}/${encodeURIComponent(iconName)}.svg`;

    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      let text = await response.text();
      text = cleanSvg(text);
      if (svgCache.size >= 256) svgCache.delete(svgCache.keys().next().value);
      svgCache.set(iconifyName, text);
      return text;
    } catch (e) {
      console.error(`[Excali Up] SVG fetch failed for ${iconifyName}:`, e);
      return null;
    }
  }

  function cleanSvg(svgText) {
    svgText = svgText.replace(/<\?xml.*?\?>/gi, '');
    svgText = svgText.replace(/<!DOCTYPE.*?>/gi, '');
    const cleanedSvg = svgText
      .replace(/fill="#(000000|000|212121)"/gi, 'fill="currentColor"')
      .replace(/stroke="#(000000|000|212121)"/gi, 'stroke="currentColor"');
    return Core.sizeSvgForCanvas(cleanedSvg, 96);
  }

  function showToast(message) {
    let toast = document.getElementById('excaligif-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'excaligif-toast';
      toast.className = 'excaligif-toast';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('show');
    if (toast.timer) clearTimeout(toast.timer);
    toast.timer = setTimeout(() => {
      toast.classList.remove('show');
    }, 2000);
  }

  checkInstance();
})();

